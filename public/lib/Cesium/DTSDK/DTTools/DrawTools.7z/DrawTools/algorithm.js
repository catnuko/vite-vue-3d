import PlotUtils from './PlotUtils.js';
import Cartesian3 from '../../../Core/Cartesian3.js';
    function algorithm (){
        this._doubleArrowDefualParam={
            "type": "doublearrow",
            "headHeightFactor": .25,
            "headWidthFactor": .3,
            "neckHeightFactor": .85,
            "fixPointCount": 4,
            "neckWidthFactor": .15
        };
        this._tailedAttackArrowDefualParam={
            "headHeightFactor": .18,
            "headWidthFactor": .3,
            "neckHeightFactor": .85,
            "neckWidthFactor": .15,
            "tailWidthFactor": .1,
            "headTailFactor": .8,
            "swallowTailFactor": 1
        };
        this._fineArrowDefualParam={
            "tailWidthFactor": 0.15,
            "neckWidthFactor": 0.20,
            "headWidthFactor": 0.25,
            "headAngle": Math.PI / 8.5,
            "neckAngle": Math.PI / 13
        };
        this._PlotUtils=new PlotUtils();
    }
    Object.defineProperties(algorithm.prototype, {
        doubleArrowDefualParam: {
            get: function () {
                return this._doubleArrowDefualParam;
            }
        },
        tailedAttackArrowDefualParam: {
            get: function () {
                return this._tailedAttackArrowDefualParam;
            }
        },
        fineArrowDefualParam: {
            get: function () {
                return this._fineArrowDefualParam;
            }
        },
        PlotUtils: {
            get: function () {
                return this._PlotUtils;
            }
        }
    })
    algorithm.prototype.doubleArrow=function (inputPoint) {
        var connPoint = null;
        var tempPoint4 = null;
        var points = inputPoint;
        var result = {
            controlPoint: null,
            polygonalPoint: null
        };
        //获取已经点击的坐标数
        var t = inputPoint.length;
        if (!(2 > t)) {
            if (2 == t) return inputPoint;
            var o = points[0],
            e = points[1],
            r = points[2],
            t = inputPoint.length;
            //下面的是移动点位后的坐标
            3 == t ? tempPoint4 = this.getTempPoint4(o, e, r) : tempPoint4 = points[3],
            3 == t || 4 == t ? connPoint = this.PlotUtils.mid(o, e) : connPoint = points[4];
            var n, g;
            this.PlotUtils.isClockWise(o, e, r) ? (n = this.getArrowPoints(o, connPoint, tempPoint4, !1), g = this.getArrowPoints(connPoint, e, r, !0)) : (n = this.getArrowPoints(e, connPoint, r, !1), g = this.getArrowPoints(connPoint, o, tempPoint4, !0));
            var i = n.length,
            s = (i - 5) / 2,
            a = n.slice(0, s),
            l = n.slice(s, s + 5),
            u = n.slice(s + 5, i),
            c = g.slice(0, s),
            p = g.slice(s, s + 5),
            h = g.slice(s + 5, i);
            c = this.PlotUtils.getBezierPoints(c);
            var d = this.PlotUtils.getBezierPoints(h.concat(a.slice(1)));
            u = this.PlotUtils.getBezierPoints(u);
            var f = c.concat(p, d, l, u);
            var newArray = this.array2Dto1D(f);
            result.controlPoint = [o, e, r, tempPoint4, connPoint];
            result.polygonalPoint = Cartesian3.fromDegreesArray(newArray);
        }
        return result;
    }
    algorithm.prototype.threeArrow=function (inputPoint) {
        var connPoint = null;
        var tempPoint4 = null;
        var tempPoint5 = null;
        var points = inputPoint;
        var result = {
            controlPoint: null,
            polygonalPoint: null
        };
        //获取已经点击的坐标数
        var t = inputPoint.length;
        if (t >= 2) {
            if (t == 2) {
                return inputPoint;
            }
            var o = points[0],
            e = points[1],
            r = points[2],
            t = inputPoint.length;
            //下面的是移动点位后的坐标
            if (t == 3) {
                tempPoint4 = this.getTempPoint4(o, e, r);
                tempPoint5 = this.PlotUtils.mid(r, tempPoint4);
            } else {
                tempPoint4 = points[3];
                tempPoint5 = points[4];
            }
            if (t < 6) {
                connPoint = this.PlotUtils.mid(o, e);
            } else {
                connPoint = points[5];
            }
            var n, g;
            if (this.PlotUtils.isClockWise(o, e, r)) {
                n = this.getArrowPoints(o, connPoint, tempPoint4, !1);
                g = this.getArrowPoints(connPoint, e, r, !0);
            } else {
                n = this.getArrowPoints(e, connPoint, r, !1);
                g = this.getArrowPoints(connPoint, o, tempPoint4, !0);
            }
            var i = n.length,
            s = (i - 5) / 2,
            a = n.slice(0, s),
            l = n.slice(s, s + 5),
            u = n.slice(s + 5, i),
            c = g.slice(0, s),
            p = g.slice(s, s + 5),
            h = g.slice(s + 5, i);
            c = this.PlotUtils.getBezierPoints(c);
            var d = this.PlotUtils.getBezierPoints(h.concat(a.slice(1)));
            u = this.PlotUtils.getBezierPoints(u);
            var f = c.concat(p, d, l, u);
            var newArray = this.array2Dto1D(f);
            result.controlPoint = [o, e, r, tempPoint4, tempPoint5, connPoint];
            result.polygonalPoint = Cartesian3.fromDegreesArray(newArray);
        }
        return result;
    }
    algorithm.prototype.array2Dto1D=function (array) {
        var newArray = [];
        array.forEach(function (elt) {
            newArray.push(elt[0]);
            newArray.push(elt[1]);
        });
        return newArray;
    }
    algorithm.prototype.getArrowPoints=function (t, o, e, r) {
        var type = this.doubleArrowDefualParam.type;
        var headHeightFactor = this.doubleArrowDefualParam.headHeightFactor;
        var headWidthFactor = this.doubleArrowDefualParam.headWidthFactor;
        var neckHeightFactor = this.doubleArrowDefualParam.neckHeightFactor;
        var neckWidthFactor = this.doubleArrowDefualParam.neckWidthFactor;
        var n = this.PlotUtils.mid(t, o),
        g = this.PlotUtils.distance(n, e),
        i = this.PlotUtils.getThirdPoint(e, n, 0, .3 * g, !0),
        s = this.PlotUtils.getThirdPoint(e, n, 0, .5 * g, !0);
        i = this.PlotUtils.getThirdPoint(n, i,  this.PlotUtils.HALF_PI, g / 5, r),
        s = this.PlotUtils.getThirdPoint(n, s,  this.PlotUtils.HALF_PI, g / 4, r);
        var a = [n, i, s, e],
        l = this.getArrowHeadPoints(a, headHeightFactor, headWidthFactor, neckHeightFactor, neckWidthFactor),
        u = l[0],
        c = l[4],
        p = this.PlotUtils.distance(t, o) / this.PlotUtils.getBaseLength(a) / 2,
        h = this.getArrowBodyPoints(a, u, c, p),
        d = h.length,
        f = h.slice(0, d / 2),
        E = h.slice(d / 2, d);
        return f.push(u),
        E.push(c),
        f = f.reverse(),
        f.push(o),
        E = E.reverse(),
        E.push(t),
        f.reverse().concat(l, E)
    }
    algorithm.prototype.getArrowHeadPoints=function (t, o, e) {
        var type = this.doubleArrowDefualParam.type;
        var headHeightFactor = this.doubleArrowDefualParam.headHeightFactor;
        var headWidthFactor = this.doubleArrowDefualParam.headWidthFactor;
        var neckHeightFactor = this.doubleArrowDefualParam.neckHeightFactor;
        var neckWidthFactor = this.doubleArrowDefualParam.neckWidthFactor;
        var r = this.PlotUtils.getBaseLength(t),
        n = r * headHeightFactor,
        g = t[t.length - 1],
        i = (this.PlotUtils.distance(o, e), n * headWidthFactor),
        s = n * neckWidthFactor,
        a = n * neckHeightFactor,
        l = this.PlotUtils.getThirdPoint(t[t.length - 2], g, 0, n, !0),
        u = this.PlotUtils.getThirdPoint(t[t.length - 2], g, 0, a, !0),
        c = this.PlotUtils.getThirdPoint(g, l,  this.PlotUtils.HALF_PI, i, !1),
        p = this.PlotUtils.getThirdPoint(g, l,  this.PlotUtils.HALF_PI, i, !0),
        h = this.PlotUtils.getThirdPoint(g, u,  this.PlotUtils.HALF_PI, s, !1),
        d = this.PlotUtils.getThirdPoint(g, u,  this.PlotUtils.HALF_PI, s, !0);
        return [h, c, g, p, d];
    }
    algorithm.prototype.getArrowBodyPoints=function (t, o, e, r) {
        for (var n = this.PlotUtils.wholeDistance(t), g = this.PlotUtils.getBaseLength(t), i = g * r, s = this.PlotUtils.distance(o, e), a = (i - s) / 2, l = 0, u = [], c = [], p = 1; p < t.length - 1; p++) {
            var h = this.PlotUtils.getAngleOfThreePoints(t[p - 1], t[p], t[p + 1]) / 2;
            l += this.PlotUtils.distance(t[p - 1], t[p]);
            var d = (i / 2 - l / n * a) / Math.sin(h),
            f = this.PlotUtils.getThirdPoint(t[p - 1], t[p], Math.PI - h, d, !0),
            E = this.PlotUtils.getThirdPoint(t[p - 1], t[p], h, d, !1);
            u.push(f),
            c.push(E)
        }
        return u.concat(c)
    }
    algorithm.prototype.getTempPoint4=function (t, o, e) {
        var r, n, g, i, s = this.PlotUtils.mid(t, o),
        a = this.PlotUtils.distance(s, e),
        l = this.PlotUtils.getAngleOfThreePoints(t, s, e);
        return l <  this.PlotUtils.HALF_PI ? (n = a * Math.sin(l), g = a * Math.cos(l), i = this.PlotUtils.getThirdPoint(t, s,  this.PlotUtils.HALF_PI, n, !1), r = this.PlotUtils.getThirdPoint(s, i,  this.PlotUtils.HALF_PI, g, !0)) : l >=  this.PlotUtils.HALF_PI && l < Math.PI ? (n = a * Math.sin(Math.PI - l), g = a * Math.cos(Math.PI - l), i = this.PlotUtils.getThirdPoint(t, s,  this.PlotUtils.HALF_PI, n, !1), r = this.PlotUtils.getThirdPoint(s, i,  this.PlotUtils.HALF_PI, g, !1)) : l >= Math.PI && l < 1.5 * Math.PI ? (n = a * Math.sin(l - Math.PI), g = a * Math.cos(l - Math.PI), i = this.PlotUtils.getThirdPoint(t, s,  this.PlotUtils.HALF_PI, n, !0), r = this.PlotUtils.getThirdPoint(s, i,  this.PlotUtils.HALF_PI, g, !0)) : (n = a * Math.sin(2 * Math.PI - l), g = a * Math.cos(2 * Math.PI - l), i = this.PlotUtils.getThirdPoint(t, s,  this.PlotUtils.HALF_PI, n, !0), r = this.PlotUtils.getThirdPoint(s, i,  this.PlotUtils.HALF_PI, g, !1)),
        r
    }
    algorithm.prototype.tailedAttackArrow=function (inputPoint) {
        inputPoint = this.dereplication(inputPoint);
        var tailWidthFactor = this.tailedAttackArrowDefualParam.tailWidthFactor;
        var swallowTailFactor = this.tailedAttackArrowDefualParam.swallowTailFactor;
        var swallowTailPnt = this.tailedAttackArrowDefualParam.swallowTailPnt;
        //控制点
        var result = {
            controlPoint: null,
            polygonalPoint: null
        };
        result.controlPoint = inputPoint;
        var t = inputPoint.length;
        if (!(2 > t)) {
            if (2 == inputPoint.length) {
                result.polygonalPoint = inputPoint;
                return result;
            }
            var o = inputPoint,
            e = o[0],
            r = o[1];
            this.PlotUtils.isClockWise(o[0], o[1], o[2]) && (e = o[1], r = o[0]);
            var n = this.PlotUtils.mid(e, r),
            g = [n].concat(o.slice(2)),
            i = this.getAttackArrowHeadPoints(g, e, r, this.tailedAttackArrowDefualParam),
            s = i[0],
            a = i[4],
            l = this.PlotUtils.distance(e, r),
            u = this.PlotUtils.getBaseLength(g),
            c = u * tailWidthFactor * swallowTailFactor;
            swallowTailPnt = this.PlotUtils.getThirdPoint(g[1], g[0], 0, c, !0);
            var p = l / u,
            h = this.getAttackArrowBodyPoints(g, s, a, p),
            t = h.length,
            d = [e].concat(h.slice(0, t / 2));
            d.push(s);
            var f = [r].concat(h.slice(t / 2, t));
            var newArray = [];
            f.push(a),
            d = this.PlotUtils.getQBSplinePoints(d),
            f = this.PlotUtils.getQBSplinePoints(f),
            newArray = this.array2Dto1D(d.concat(i, f.reverse(), [swallowTailPnt, d[0]]));
            result.polygonalPoint = Cartesian3.fromDegreesArray(newArray);
        }
        return result;
    }
    algorithm.prototype.getAttackArrowHeadPoints=function (t, o, e, defaultParam) {
        var headHeightFactor = defaultParam.headHeightFactor;
        var headTailFactor = defaultParam.headTailFactor;
        var headWidthFactor = defaultParam.headWidthFactor;
        var neckWidthFactor = defaultParam.neckWidthFactor;
        var neckHeightFactor = defaultParam.neckHeightFactor;
        var r = this.PlotUtils.getBaseLength(t),
        n = r * headHeightFactor,
        g = t[t.length - 1];
        r = this.PlotUtils.distance(g, t[t.length - 2]);
        var i = this.PlotUtils.distance(o, e);
        n > i * headTailFactor && (n = i * headTailFactor);
        var s = n * headWidthFactor,
        a = n * neckWidthFactor;
        n = n > r ? r : n;
        var l = n * neckHeightFactor,
        u = this.PlotUtils.getThirdPoint(t[t.length - 2], g, 0, n, !0),
        c = this.PlotUtils.getThirdPoint(t[t.length - 2], g, 0, l, !0),
        p = this.PlotUtils.getThirdPoint(g, u,  this.PlotUtils.HALF_PI, s, !1),
        h = this.PlotUtils.getThirdPoint(g, u,  this.PlotUtils.HALF_PI, s, !0),
        d = this.PlotUtils.getThirdPoint(g, c,  this.PlotUtils.HALF_PI, a, !1),
        f = this.PlotUtils.getThirdPoint(g, c,  this.PlotUtils.HALF_PI, a, !0);
        return [d, p, g, h, f]
    }
    algorithm.prototype.getAttackArrowBodyPoints= function (t, o, e, r) {
        for (var n = this.PlotUtils.wholeDistance(t), g = this.PlotUtils.getBaseLength(t), i = g * r, s = this.PlotUtils.distance(o, e), a = (i - s) / 2, l = 0, u = [], c = [], p = 1; p < t.length - 1; p++) {
            var h = this.PlotUtils.getAngleOfThreePoints(t[p - 1], t[p], t[p + 1]) / 2;
            l += this.PlotUtils.distance(t[p - 1], t[p]);
            var d = (i / 2 - l / n * a) / Math.sin(h),
            f = this.PlotUtils.getThirdPoint(t[p - 1], t[p], Math.PI - h, d, !0),
            E = this.PlotUtils.getThirdPoint(t[p - 1], t[p], h, d, !1);
            u.push(f),
            c.push(E)
        }
        return u.concat(c)
    }
    algorithm.prototype.dereplication=function (array) {
        var last = array[array.length - 1];
        var change = false;
        var newArray = [];
        newArray = array.filter(function (i) {
            if (i[0] != last[0] && i[1] != last[1]) {
                return i;
            }
            change = true;
        });
        if (change) newArray.push(last);
        return newArray;
    }
    algorithm.prototype.fineArrow=function (tailPoint, headerPoint) {
        if ((tailPoint.length < 2) || (headerPoint.length < 2)) return;
        //画箭头的函数
        var tailWidthFactor = this.fineArrowDefualParam.tailWidthFactor;
        var neckWidthFactor = this.fineArrowDefualParam.neckWidthFactor;
        var headWidthFactor = this.fineArrowDefualParam.headWidthFactor;
        var headAngle = this.fineArrowDefualParam.headAngle;
        var neckAngle = this.fineArrowDefualParam.neckAngle;
        var o = [];
        o[0] = tailPoint;
        o[1] = headerPoint;
        var e = o[0],
        r = o[1],
        n = this.PlotUtils.getBaseLength(o),
        g = n * tailWidthFactor,
        //尾部宽度因子
        i = n * neckWidthFactor,
        //脖子宽度银子
        s = n * headWidthFactor,
        //头部宽度因子
        a = this.PlotUtils.getThirdPoint(r, e,  this.PlotUtils.HALF_PI, g, !0),
        l = this.PlotUtils.getThirdPoint(r, e,  this.PlotUtils.HALF_PI, g, !1),
        u = this.PlotUtils.getThirdPoint(e, r, headAngle, s, !1),
        c = this.PlotUtils.getThirdPoint(e, r, headAngle, s, !0),
        p = this.PlotUtils.getThirdPoint(e, r, neckAngle, i, !1),
        h = this.PlotUtils.getThirdPoint(e, r, neckAngle, i, !0),
        d = [];
        d.push(a[0], a[1], p[0], p[1], u[0], u[1], r[0], r[1], c[0], c[1], h[0], h[1], l[0], l[1], e[0], e[1]);
        return Cartesian3.fromDegreesArray(d);
    }
export default algorithm
