/*
 * @Author: your name
 * @Date: 2020-05-13 09:08:43
 * @LastEditTime: 2020-07-15 15:36:19
 * @LastEditors: 刘铭崴
 * @Description: In User Settings Edit
 * @FilePath: \dtglobesdk\Source\DTSDK\DTTools\DrawTools\DTDraw.js
 */
import DTTracker from './DTTracker.js';
import DTDrawFuncTool from './DTDrawFuncTool.js';
import ScreenSpaceEventHandler from '../../../Core/ScreenSpaceEventHandler.js';
import ScreenSpaceEventType from '../../../Core/ScreenSpaceEventType.js';
import defaultValue from '../../../Core/defaultValue.js';
import defined from '../../../Core/defined.js';
import createGuid from '../../../Core/createGuid.js';
/**
 * @alias DTDraw
 * @constructor
 * @description DTDraw 绘制工具类,提供基本的绘制、编辑、删除功能，可传入回调函数，绘制结束后执行回调函数
 * @param {Viewer} [viewer] Viewer实例对象:
 */
function DTDraw(viewer){
    this._viewer=viewer;
    this._shapeDic=[];
    this._layerId='drawGeometry';
    this._flag=0;
    this._tracker = new DTTracker(viewer);
    this._editing=false;
    this._handler=undefined;
    this._callback=undefined;//回调函数
    this._callbackParams=undefined;//回调参数
    bindGloveEvent(this);
    viewer.cesiumWidget.screenSpaceEventHandler.removeInputAction(ScreenSpaceEventType.LEFT_DOUBLE_CLICK);
}
/**
*绘制点
* @memberof DTDraw
*
* @param {Object} [options] 具有以下属性的对象,该参数为可选参数
* @param {Boolean} [options.show] 是否显示绘制实体
* @param {Function} [options.callback] 绘制结束之后的回调函数
* @param {Object} [options.parameters] 回调函数的参数
*/
DTDraw.prototype.drawPoint=function(options={}){
    if (!defined(options.show)) {
        options.show=true;
    }
    if (this._editing) {
       alert("请先完成当前编辑操作!");
    } else {
       if (defined(this._tracker)) {
            let _this=this;
            _this._flag = 0;
            _this._tracker.trackPoint(function (position) {
                var objId = createGuid();//(new Date()).getTime();
                _this._shapeDic[objId] = position;
                DTDrawFuncTool.showPoint(objId, position,_this,options);
            });
       }
    }
}
/**
*绘制圆
* @memberof DTDraw
*
* @param {Object} [options] 具有以下属性的对象,该参数为可选参数
* @param {Boolean} [options.show] 是否显示绘制实体
* @param {Function} [options.callback] 绘制结束之后的回调函数
* @param {Object} [options.parameters] 回调函数的参数
*/
DTDraw.prototype.drawCircle=function(options={}){
    if (!defined(options.show)) {
        options.show=true;
    }
    if (this._editing) {
       alert("请先完成当前编辑操作!");
    } else {
        if (defined(this._tracker)) {
            let _this=this;
            _this._flag = 0;
            _this._tracker.trackCircle(function (positions) {
               var objId = createGuid();//(new Date()).getTime();
               _this._shapeDic[objId] = positions;
               DTDrawFuncTool.showCircle(objId, positions,_this,options);
           });
        }
    }
}
/**
*绘制矩形
* @memberof DTDraw
*
* @param {Object} [options] 具有以下属性的对象,该参数为可选参数
* @param {Boolean} [options.show] 是否显示绘制实体
* @param {Function} [options.callback] 绘制结束之后的回调函数
* @param {Object} [options.parameters] 回调函数的参数
*/
DTDraw.prototype.drawRectangle=function(options={}){
    if (!defined(options.show)) {
        options.show=true;
    }
    if (this._editing) {
       alert("请先完成当前编辑操作!");
    } else {
        if (defined(this._tracker)) {
            let _this=this;
            _this._flag = 0;
            _this._tracker.trackRectangle(function (positions) {
                var objId = createGuid();//(new Date()).getTime();
                _this._shapeDic[objId] = positions;
                DTDrawFuncTool.showRectangle(objId, positions,_this,options);
            });
        }
    }
}
/**
*绘制折线
* @memberof DTDraw
*
* @param {Object} [options] 具有以下属性的对象,该参数为可选参数
* @param {Boolean} [options.show] 是否显示绘制实体
* @param {Function} [options.callback] 绘制结束之后的回调函数
* @param {Object} [options.parameters] 回调函数的参数
*/
DTDraw.prototype.drawPolyline=function(options={}){
    if (!defined(options.show)) {
        options.show=true;
    }
    if (this._editing) {
       alert("请先完成当前编辑操作!");
    } else {
        if (defined(this._tracker)) {
            let _this=this;
            _this._flag = 0;
            _this._tracker.trackPolyline(function (positions) {
                var objId = createGuid();//(new Date()).getTime();
                _this._shapeDic[objId] = positions;
                DTDrawFuncTool.showPolyline(objId, positions,_this,options,options);
            });
        }
    }
}
/**
*绘制多边形
* @memberof DTDraw
*
* @param {Object} [options] 具有以下属性的对象,该参数为可选参数
* @param {Boolean} [options.show] 是否显示绘制实体
* @param {Function} [options.callback] 绘制结束之后的回调函数
* @param {Object} [options.parameters] 回调函数的参数
*/
DTDraw.prototype.drawPolygon=function(options={}){
    if (!defined(options.show)) {
        options.show=true;
    }
   if (this._editing) {
       alert("请先完成当前编辑操作!");
   } else {
    if (defined(this._tracker)) {
        let _this=this;
        _this._flag = 0;
        _this._tracker.trackPolygon(function (positions) {
            var objId = createGuid();// (new Date()).getTime();
            _this._shapeDic[objId] = positions;
            DTDrawFuncTool.showPolygon(objId, positions,_this,options);
        });
    }
   }
}
/**
*绘制进攻箭头
* @memberof DTDraw
*
* @param {Object} [options] 具有以下属性的对象,该参数为可选参数
* @param {Boolean} [options.show] 是否显示绘制实体
* @param {Function} [options.callback] 绘制结束之后的回调函数
* @param {Object} [options.parameters] 回调函数的参数
*/
DTDraw.prototype.drawAttackArrow=function(options={}){
    if (!defined(options.show)) {
        options.show=true;
    }
    if (this._editing) {
       alert("请先完成当前编辑操作!");
    } else {
       if (defined(this._tracker)) {
            let _this=this;
            _this._flag = 0;
            _this._tracker.trackAttackArrow(function (positions, custom) {
                var objId = createGuid();//(new Date()).getTime();
                _this._shapeDic[objId] = {
                    custom: custom,
                    positions: positions
                };
                DTDrawFuncTool.showAttackArrow(objId, positions,_this,options);
            });
       }
    }
}
/**
*绘制直线箭头
* @memberof DTDraw
*
* @param {Object} [options] 具有以下属性的对象,该参数为可选参数
* @param {Boolean} [options.show] 是否显示绘制实体
* @param {Function} [options.callback] 绘制结束之后的回调函数
* @param {Object} [options.parameters] 回调函数的参数
*/
DTDraw.prototype.drawStraightArrow=function(options={}){
    if (!defined(options.show)) {
        options.show=true;
    }
    if (this._editing) {
       alert("请先完成当前编辑操作!");
    } else {
        if (defined(this._tracker)) {
            let _this=this;
            _this._flag = 0;
            _this._tracker.trackStraightArrow(function (positions) {
                var objId = createGuid();//(new Date()).getTime();
                _this._shapeDic[objId] = positions;
                DTDrawFuncTool.showStraightArrow(objId, positions,_this,options);
            });
        }
    }
}
/**
*绘制夹击箭头
* @memberof DTDraw
*
* @param {Object} [options] 具有以下属性的对象,该参数为可选参数
* @param {Boolean} [options.show] 是否显示绘制实体
* @param {Function} [options.callback] 绘制结束之后的回调函数
* @param {Object} [options.parameters] 回调函数的参数
*/
DTDraw.prototype.drawPincerArrow=function(options={}){
    if (!defined(options.show)) {
        options.show=true;
    }
    if (this._editing) {
       alert("请先完成当前编辑操作！");
    } else {
        if (defined(this._tracker)) {
            let _this=this;
            _this._flag = 0;
            _this._tracker.trackPincerArrow(function (positions, custom) {
                var objId = createGuid();//(new Date()).getTime();
                _this._shapeDic[objId] = {
                    custom: custom,
                    positions: positions
                };
                DTDrawFuncTool.showPincerArrow(objId, positions,_this,options);
            });
        }
    }
}
/**
*设置编辑结束的方式
* @memberof DTDraw
* @param {Boolean} [CartWay] false表示globe.pick，true表示scene.pickPosition
*/
DTDraw.prototype.setCartWay=function(CartWay){
    this._tracker.setCartWay(CartWay);
}
/**
*设置获取坐标的方式
* @memberof DTDraw
* @param {Boolean} [endDrawWay] true为右键结束编辑，false为默认左键结束（即每次只能编辑一个点）
*/
DTDraw.prototype.setEndDrawWay=function(endDrawWay){
    this._tracker.setEndDrawWay(endDrawWay);
}
/**
*编辑
* @memberof DTDraw
*/
DTDraw.prototype.edit=function(){
    if (this._editing) {
        alert("请先完成当前编辑操作!");
    } else {
        if (defined(this._tracker)) {
            this._flag = 1;
            //清除标绘状态
            this._tracker.clear();
        }
    }
}
/**
*删除
* @memberof DTDraw
*/
DTDraw.prototype.delete=function(){
    if (this._editing) {
       alert("请先完成当前编辑操作!");
    } else {
        if (defined(this._tracker)) {
            this._flag = 2;
            //清除标绘状态
            this._tracker.clear();
        }
    }
}
/**
*销毁绘制类的实例对象
* @memberof DTDraw
*/
DTDraw.prototype.destory=function(){
    this._viewer=undefined;
    this._shapeDic=[];
    this._flag=0;
    this._tracker =undefined;
    this._editing=false;
    this._handler=undefined;
    this._viewer.cesiumWidget.screenSpaceEventHandler.setInputAction(ScreenSpaceEventType.LEFT_DOUBLE_CLICK);
}
//初始化绑定事件，私有函数
function bindGloveEvent(dtDraw) {
    dtDraw._handler = new ScreenSpaceEventHandler(dtDraw._viewer.scene.canvas);
    dtDraw._handler.setInputAction(function (movement) {
        var pick = dtDraw._viewer.scene.pick(movement.position);
        if (!pick) {
            return;
        }
        var obj = pick.id;
        if (!obj || !obj.layerId || dtDraw._flag == 0) {
            return;
        }
        var objId = obj.objId;
        //flag为编辑或删除标识,1为编辑，2为删除
        if (dtDraw._flag == 1) {
            dtDraw._editing=true;
            dtDraw._callback=obj.callbackAndParams.callback;
            dtDraw._callbackParams=obj.callbackAndParams.params;
            switch (obj.shapeType) {
                case "Polygon":
                    dtDraw._flag = 0;
                    DTDrawFuncTool.editPolygon(objId,dtDraw);
                    break;
                case "Polyline":
                    dtDraw._flag = 0;
                    DTDrawFuncTool.editPolyline(objId,dtDraw);
                    break;
                case "Rectangle":
                    dtDraw._flag = 0;
                    DTDrawFuncTool.editRectangle(objId,dtDraw);
                    break;
                case "Circle":
                    dtDraw._flag = 0;
                    DTDrawFuncTool.editCircle(objId,dtDraw);
                    break;
                case "Point":
                    dtDraw._flag = 0;
                    DTDrawFuncTool.editPoint(objId,dtDraw);
                    break;
                case "StraightArrow":
                    dtDraw._flag = 0;
                    DTDrawFuncTool.editStraightArrow(objId,dtDraw);
                    break;
                case "AttackArrow":
                    dtDraw._flag = 0;
                    DTDrawFuncTool.editAttackArrow(objId,dtDraw);
                    break;
                case "PincerArrow":
                    dtDraw._flag = 0;
                    DTDrawFuncTool.editPincerArrow(objId,dtDraw);
                    break;
                default:
                    break;
            }
        } else if (dtDraw._flag == 2) {
            DTDrawFuncTool.clearEntityById(objId,dtDraw);
        }
    }, ScreenSpaceEventType.LEFT_CLICK);
}
export default DTDraw
