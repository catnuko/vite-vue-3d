import DTTooltip from './DTTooltip.js';
import ScreenSpaceEventHandler from '../../../Core/ScreenSpaceEventHandler.js';
import defined from '../../../Core/defined.js';
import ScreenSpaceEventType from '../../../Core/ScreenSpaceEventType.js';
import ConstantProperty from '../../../DataSources/ConstantProperty.js';
import HeightReference from '../../../Scene/HeightReference.js';
import Cartesian3 from '../../../Core/Cartesian3.js';
import Cartesian2 from '../../../Core/Cartesian2.js';
import Color from '../../../Core/Color.js';
import PolylineDashMaterialProperty from '../../../DataSources/PolylineDashMaterialProperty.js';
import CallbackProperty from '../../../DataSources/CallbackProperty.js';
import LabelStyle from '../../../Scene/LabelStyle.js';
import PolygonGraphics from '../../../DataSources/PolygonGraphics.js';
import EllipsoidGeodesic from '../../../Core/EllipsoidGeodesic.js';
import EllipseGeometryLibrary from '../../../Core/EllipseGeometryLibrary.js';
import buildModuleUrl from '../../../Core/buildModuleUrl.js';
import algorithm from './algorithm.js';
import Math from '../../../Core/Math.js';
import SceneTransforms from '../../../Scene/SceneTransforms.js';
import Rectangle from '../../../Core/Rectangle.js';
import ClassificationType from '../../../Scene/ClassificationType.js';
    /**
     * @alias DTRectangleDrawer
     * @constructor
     * @description DTRectangleDrawer矩形绘制类
     * @param {Viewer} [viewer] Viewer实例对象:
     */
    function DTRectangleDrawer(viewer) {
        this._viewer = viewer;
        this._scene = viewer.scene;
        this._clock = viewer.clock;
        this._canvas = viewer.scene.canvas;
        this._camera = viewer.scene.camera;
        this._ellipsoid = viewer.scene.globe.ellipsoid;
        this._tooltip = new DTTooltip(viewer.container);
        this._entity = null;
        this._tempPositions = [];
        this._positions = [];
        this._drawHandler = null;
        this._modifyHandler = null;
        this._okHandler = null;
        this._cancelHandler = null;
        this._dragIcon = buildModuleUrl("Assets/Images/circle_gray.png");
        this._dragIconLight = buildModuleUrl("Assets/Images/circle_red.png");
        this._material = null;
        this._outlineMaterial = null;
        this._fill = true;
        this._outline = true;
        this._outlineWidth = 3;
        this._extrudedHeight = 0;
        this._toolBarIndex = null;
        this._executeHandlerType = null;
        this._markers = {};
        this._layerId = "globeEntityDrawerLayer";
        this._classificationType=ClassificationType.BOTH;//新增
        this._rightClickEndDraw=false;//新增是否右键结束绘制
    }
    Object.defineProperties(DTRectangleDrawer.prototype, {
        /**
         * viewer实例对象
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        viewer: {
            get: function () {
                return this._viewer;
            }
        },
         /**
         * scene实例对象
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        scene: {
            get: function () {
                return this._scene;
            }
        },
         /**
         * clock实例对象
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        clock: {
            get: function () {
                return this._clock;
            }
        },
        /**
         * canvas实例对象
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        canvas: {
            get: function () {
                return this._canvas;
            }
        },
        /**
         * camera实例对象
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        camera: {
            get: function () {
                return this._camera;
            }
        },
         /**
         * ellipsoid实例对象
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        ellipsoid: {
            get: function () {
                return this._ellipsoid;
            }
        },
        /**
         * tooltip实例对象
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        tooltip: {
            get: function () {
                return this._tooltip;
            }
        },
        /**
         * 当前绘制entity对象
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        entity: {
            get: function () {
                return this._entity;
            },
            set: function (value) {
                this._entity = value
            }
        },
        /**
         * 绘制过程的临时点
         * @memberof DTRectangleDrawer.prototype
         * @type {Array}
         */
        tempPositions: {
            get: function () {
                return this._tempPositions;
            },
            set: function (value) {
                this._tempPositions = value
            }
        },
        /**
         * 绘制矩形的点
         * @memberof DTRectangleDrawer.prototype
         * @type {Array}
         */
        positions: {
            get: function () {
                return this._positions;
            },
            set: function (value) {
                this._positions = value
            }
        },
         /**
         * 绘制矩形的Handler
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        drawHandler: {
            get: function () {
                return this._drawHandler;
            },
            set: function (value) {
                this._drawHandler = value
            }
        },
        /**
         * 编辑矩形的Handler
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        modifyHandler: {
            get: function () {
                return this._modifyHandler;
            },
            set: function (value) {
                this._modifyHandler = value
            }
        },
        /**
         * 生成矩形的回调函数，也可以仅仅获取点
         * @memberof DTRectangleDrawer.prototype
         * @type {Function}
         */
        okHandler: {
            get: function () {
                return this._okHandler;
            },
            set: function (value) {
                this._okHandler = value
            }
        },
        /**
         * 取消生成矩形的回调函数
         * @memberof DTRectangleDrawer.prototype
         * @type {Function}
         */
        cancelHandler: {
            get: function () {
                return this._cancelHandler;
            },
            set: function (value) {
                this._cancelHandler = value
            }
        },
        /**
         * 矩形的材质
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        material: {
            get: function () {
                return this._material;
            },
            set: function (value) {
                this._material = value
            }
        },
         /**
         * 矩形的外轮廓线材质
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        outlineMaterial: {
            get: function () {
                return this._outlineMaterial;
            },
            set: function (value) {
                this._outlineMaterial = value
            }
        },
         /**
         * 矩形是否填充
         * @memberof DTRectangleDrawer.prototype
         * @type {Boolean}
         */
        fill: {
            get: function () {
                return this._fill;
            },
            set: function (value) {
                this._fill = value
            }
        },
        /**
         * 矩形是否显示外轮廓线
         * @memberof DTRectangleDrawer.prototype
         * @type {Boolean}
         */
        outline: {
            get: function () {
                return this._outline;
            },
            set: function (value) {
                this._outline = value
            }
        },
         /**
         * 矩形外轮廓线的宽度
         * @memberof DTRectangleDrawer.prototype
         * @type {Int}
         */
        outlineWidth: {
            get: function () {
                return this._outlineWidth;
            },
            set: function (value) {
                this._outlineWidth = value
            }
        },
        /**
         * 矩形的拉伸高度
         * @memberof DTRectangleDrawer.prototype
         * @type {Int}
         */
        extrudedHeight: {
            get: function () {
                return this._extrudedHeight;
            },
            set: function (value) {
                this._extrudedHeight = value
            }
        },
         /**
         * 标识entity
         * @memberof DTRectangleDrawer.prototype
         * @type {String}
         */
        layerId: {
            get: function () {
                return this._layerId;
            }
        },
        /**
         * 执行Handler的类型
         * @memberof DTRectangleDrawer.prototype
         * @type {Boolean}
         */
        executeHandlerType: {
            get: function () {
                return this._executeHandlerType;
            },
            set: function (value) {
                this._executeHandlerType = value
            }
        },
        /**
         * 提示点
         * @memberof DTRectangleDrawer.prototype
         * @type {Object}
         */
        markers: {
            get: function () {
                return this._markers;
            },
            set: function (value) {
                this._markers = value
            }
        },
         /**
         *  classificationType类型（分为贴地、贴模型、既贴地又贴模型）
         * @memberof DTRectangleDrawer.prototype
         * @type {Int}
         */
        classificationType: {
            get: function () {
                return this._classificationType;
            },
            set: function (value) {
                this._classificationType = value
            }
        },
         /**
         *  是否启用右键结束事件（暂留）
         * @memberof DTRectangleDrawer.prototype
         * @type {Int}
         */
        rightClickEndDraw:{
            get:function(){
               return this._rightClickEndDraw;
            },
            set:function(value){
              this._rightClickEndDraw=value;
            }
        }
    })
    /**
     * 绘制命令销毁，并不是类的销毁
     */
    DTRectangleDrawer.prototype.clear = function () {
        if (this.drawHandler) {
            this.drawHandler.destroy();
            this.drawHandler = null;
        }
        if (this.modifyHandler) {
            this.modifyHandler.destroy();
            this.modifyHandler = null;
        }
        clearMarkers(this, this.layerId);
        this.tooltip.setVisible(false);
    }
     /**
     * 绘制成功结束后的回调函数
     */
    DTRectangleDrawer.prototype.excuteOkHandler = function () {
        this.clear();
        if (this.okHandler) {
            this.okHandler(this.positions);
        }

    }
    /**
     * 取消绘制结果的回调函数
     */
    DTRectangleDrawer.prototype.excuteCancelHandler = function () {
        this.clear();
        if (this.cancelHandler) {
            this.cancelHandler();
        }
    }
     /**
     * 显示绘制的geometry,用户无需调用
     */
    DTRectangleDrawer.prototype.showModifyRectangle = function (positions, okHandler, cancelHandler) {
        var _this = this;
        _this.positions = positions;
        _this.okHandler = okHandler;
        _this.cancelHandler = cancelHandler;
        //弹出diglog
        //this.tooltip.dialogShowAt(SceneTransforms.wgs84ToWindowCoordinates(this._scene, this.positions[0]), this);
        showModifyRegion2Map(_this);
        startModify(_this);
    }
    /**
     * 绘制矩形的命令，单独使用此类，可调用该方法进行绘制矩形
     * @param {Function} okHandler 生成矩形对象回调函数
     * @param {Function} cancelHandler 取消生成矩形对象函数
     */
    DTRectangleDrawer.prototype.startDrawRectangle = function (okHandler, cancelHandler) {
        var _this = this;
        _this.okHandler = okHandler;
        _this.cancelHandler = cancelHandler;
        _this.positions = [];
        var floatingPoint = null;
        _this.drawHandler = new ScreenSpaceEventHandler(_this.canvas);

        _this.drawHandler.setInputAction(function (event) {
            var position = event.position;
            if (!defined(position)) {
                return;
            }
            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            var num = _this.positions.length;
            if (num == 0) {
                _this.positions.push(cartesian);
                floatingPoint = createPoint(_this, cartesian, -1);
                showRegion2Map(_this);
            }
            _this.positions.push(cartesian);
            var oid = _this.positions.length - 2;
            createPoint(_this, cartesian, oid);
            if (num > 1) {
                _this.positions.pop();
                _this.viewer.entities.remove(floatingPoint);
                _this.tooltip.setVisible(false);
                startModify(_this);
                ///新增结束
                _this.excuteOkHandler();
            }
        }, ScreenSpaceEventType.LEFT_CLICK);

        _this.drawHandler.setInputAction(function (event) {
            var position = event.endPosition;
            if (!defined(position)) {
                return;
            }
            if (_this.positions.length < 1) {
                _this.tooltip.showAt(position, "<p>选择起点</p>");
                return;
            }
            _this.tooltip.showAt(position, "<p>选择终点</p>");

            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            floatingPoint.position.setValue(cartesian);
            _this.positions.pop();
            _this.positions.push(cartesian);
        }, ScreenSpaceEventType.MOUSE_MOVE);
    }
    //编辑矩形调用，属于内部函数
    function startModify(that) {
        var _this = that;
        var isMoving = false;
        var pickedAnchor = null;
        if (_this.drawHandler) {
            _this.drawHandler.destroy();
            _this.drawHandler = null;
        }
        _this.modifyHandler = new ScreenSpaceEventHandler(_this.canvas);

        _this.modifyHandler.setInputAction(function (event) {
            var position = event.position;
            if (!defined(position)) {
                return;
            }
            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            if (isMoving) {
                isMoving = false;
                pickedAnchor.position.setValue(cartesian);
                var oid = pickedAnchor.oid;
                _this.positions[oid] = cartesian;
                _this.tooltip.setVisible(false);
                ///新增结束
                if (!_this.rightClickEndDraw) {
                    _this.excuteOkHandler();
                }
            } else {
                var pickedObject = _this.scene.pick(position);
                if (!defined(pickedObject)) {
                    return;
                }
                if (!defined(pickedObject.id)) {
                    return;
                }
                var entity = pickedObject.id;
                if (entity.layerId != _this.layerId || entity.flag != "anchor") {
                    return;
                }
                pickedAnchor = entity;
                isMoving = true;
                _this.tooltip.showAt(position, "<p>移动控制点</p>");
            }
        }, ScreenSpaceEventType.LEFT_CLICK);

        _this.modifyHandler.setInputAction(function (event) {
            if (!isMoving) {
                return;
            }
            var position = event.endPosition;
            if (!defined(position)) {
                return;
            }
            _this.tooltip.showAt(position, "<p>移动控制点</p>");

            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            pickedAnchor.position.setValue(cartesian);
            var oid = pickedAnchor.oid;
            _this.positions[oid] = cartesian;
        }, ScreenSpaceEventType.MOUSE_MOVE);
        ////////////////////////////////新增功能编辑右键结束
        _this.modifyHandler.setInputAction(function (movement) {
            if (_this.rightClickEndDraw) {
                _this.excuteOkHandler();
            }
        }, ScreenSpaceEventType.RIGHT_CLICK);
    }
    //将绘制过程中geometry显示到地图上
    function showRegion2Map(that) {
        var _this = that;
                ////
                _this.material=null;
                _this.outlineMaterial=null;
                _this.classificationType=ClassificationType.BOTH;
                _this.outlineWidth=2;
                ///
        if (_this.material == null) {
            _this.material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        }
        if (_this.outlineMaterial == null) {
            _this.outlineMaterial = new PolylineDashMaterialProperty({
                dashLength: 16,
                color: Color.fromCssColorString('#00f').withAlpha(0.7)
            });
        }
        var dynamicPositions = new CallbackProperty(function () {
            if (_this.positions.length > 1) {
                var rect = Rectangle.fromCartesianArray(_this.positions);
                return rect;
            } else {
                return null;
            }
        }, false);
        var outlineDynamicPositions = new CallbackProperty(function () {
            if (_this.positions.length > 1) {
                var rect = Rectangle.fromCartesianArray(_this.positions);
                var arr = [rect.west, rect.north, rect.east, rect.north, rect.east, rect.south, rect.west, rect.south, rect.west, rect.north];
                var positions = Cartesian3.fromRadiansArray(arr);
                return positions;
            } else {
                return null;
            }
        }, false);
        var bData = {
            rectangle: {
                coordinates: dynamicPositions,
                material: _this.material,
                show: _this.fill,
                classificationType:_this.classificationType
            },
            polyline: {
                positions: outlineDynamicPositions,
                clampToGround: true,
                width: _this.outlineWidth,
                material: _this.outlineMaterial,
                show: _this.outline,
                classificationType:_this.classificationType
            }
        };
        if (_this.extrudedHeight > 0) {
            bData.rectangle.extrudedHeight = _this.extrudedHeight;
            bData.rectangle.extrudedHeightReference = HeightReference.RELATIVE_TO_GROUND;
            bData.rectangle.closeTop = true;
            bData.rectangle.closeBottom = true;
            bData.rectangle.outline = false;
            bData.rectangle.outlineWidth = 0;
        }
        _this.entity = _this.viewer.entities.add(bData);
        _this.entity.layerId = _this.layerId;
    }
    //编辑矩形，实时将矩形geomtry显示到地图上
    function showModifyRegion2Map(that) {
        var _this = that;
        if (_this.material == null) {
            _this.material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        }
        if (_this.outlineMaterial == null) {
            _this.outlineMaterial = new PolylineDashMaterialProperty({
                dashLength: 16,
                color: Color.fromCssColorString('#00f').withAlpha(0.7)
            });
        }
        var dynamicPositions = new CallbackProperty(function () {
            if (_this.positions.length > 1) {
                var rect = Rectangle.fromCartesianArray(_this.positions);
                return rect;
            } else {
                return null;
            }
        }, false);
        var outlineDynamicPositions = new CallbackProperty(function () {
            if (_this.positions.length > 1) {
                var rect = Rectangle.fromCartesianArray(_this.positions);
                var arr = [rect.west, rect.north, rect.east, rect.north, rect.east, rect.south, rect.west, rect.south, rect.west, rect.north];
                var positions = Cartesian3.fromRadiansArray(arr);
                return positions;
            } else {
                return null;
            }
        }, false);
        var bData = {
            rectangle: {
                coordinates: dynamicPositions,
                material: _this.material,
                show: _this.fill,
                classificationType:_this.classificationType
            },
            polyline: {
                positions: outlineDynamicPositions,
                clampToGround: true,
                width: _this.outlineWidth,
                material: _this.outlineMaterial,
                show: _this.outline,
                classificationType:_this.classificationType
            }
        };
        if (_this.extrudedHeight > 0) {
            bData.rectangle.extrudedHeight = _this.extrudedHeight;
            bData.rectangle.extrudedHeightReference = HeightReference.RELATIVE_TO_GROUND;
            bData.rectangle.closeTop = true;
            bData.rectangle.closeBottom = true;
            bData.rectangle.outline = false;
            bData.rectangle.outlineWidth = 0;
        }
        _this.entity = _this.viewer.entities.add(bData);
        _this.entity.layerId = _this.layerId;
        var positions = _this.positions;
        for (var i = 0; i < positions.length; i++) {
            createPoint(_this, positions[i], i);
        }
    }
    //未处理
    function computeRectangle(that, p1, p2) {
        var _this = that;
        var c1 = _this.ellipsoid.cartesianToCartographic(p1);
        var c2 = _this.ellipsoid.cartesianToCartographic(p2);
        var rect = Rectangle.fromCartesianArray([p1, p2]);
        return rect;
    }
    //创建中间提示点
    function createPoint(that, cartesian, oid) {
        var _this = that;
        var point = _this.viewer.entities.add({
            position: cartesian,
            billboard: {
                image: _this._dragIconLight,
                eyeOffset: new ConstantProperty(new Cartesian3(0, 0, 0)),
                heightReference: HeightReference.CLAMP_TO_GROUND
            }
        });
        point.oid = oid;
        point.layerId = _this.layerId;
        point.flag = "anchor";
        return point;
    }
    //创建端点提示点
    function clearMarkers(that, layerName) {
        var _this = that;
        var viewer = _this.viewer;
        var entityList = viewer.entities.values;
        if (entityList == null || entityList.length < 1)
            return;
        for (var i = 0; i < entityList.length; i++) {
            var entity = entityList[i];
            if (entity.layerId == layerName) {
                viewer.entities.remove(entity);
                i--;
            }
        }
    }
export default DTRectangleDrawer;
