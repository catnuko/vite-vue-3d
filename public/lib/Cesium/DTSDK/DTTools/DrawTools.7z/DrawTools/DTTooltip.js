/*
 * @Author: your name
 * @Date: 2020-03-17 08:51:34
 * @LastEditTime: 2020-05-12 10:42:20
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \DTGlobeSDK\Source\DTSDK\DTTools\DrawTools\DTTooltip.js
 */
    function DTTooltip (frameDiv){
        var modal_content=document.createElement('DIV');
        modal_content.className="modal-content";
        var modal_footer=document.createElement('footer');
        modal_footer.className="modal-footer";
        modal_content.appendChild(modal_footer);
        var btnok=document.createElement('button');
        btnok.innerHTML="确认";
        var btncancel=document.createElement('button');
        btncancel.innerHTML="取消";
        // modal_footer.appendChild(btnok);
        // modal_footer.appendChild(btncancel);
        var div = document.createElement('DIV');
        div.className = "twipsy right";
        var arrow = document.createElement('DIV');
        arrow.className = "twipsy-arrow";
        div.appendChild(arrow);
        var title = document.createElement('DIV');
        title.className = "twipsy-inner";
        div.appendChild(title);
        //document.getElementsByTagName("body")[0].appendChild(modal_content)
        frameDiv.appendChild(div);
        this._div = div;
        this._title = title;
        this._frameDiv = frameDiv;
        this._dialogDiv=modal_content;
        this._btnok=btnok;
        this._btncancel=btncancel;
    }
    //提示框显示
    DTTooltip.prototype.setVisible=function (visible) {
        this._div.style.display = visible ? 'block' : 'none';
    },
    //提示框显示的位置
    DTTooltip.prototype.showAt=function (position, message) {
        if (position && message) {
            this.setVisible(true);
            this._title.innerHTML = message;
            this._div.style.left = position.x + 10 + "px";
            this._div.style.top = (position.y - this._div.clientHeight / 2) + "px";
        }
    }
    DTTooltip.prototype.setDialogVisible=function (visible) {
        this._dialogDiv.style.display = visible ? 'block' : 'none';
    }
    //暂留
    DTTooltip.prototype.dialogShowAt=function (position, that) {
    }
export default DTTooltip;
