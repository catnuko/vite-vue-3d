/*
 * @Author: your name
 * @Date: 2020-05-13 08:47:04
 * @LastEditTime: 2020-05-31 18:24:43
 * @LastEditors: 刘铭崴
 * @Description: In User Settings Edit
 * @FilePath: \dtglobesdk\Source\DTSDK\DTTools\DrawTools\DTDrawFuncTool.js
 */
import defined from '../../../Core/defined.js';
import ConstantProperty from '../../../DataSources/ConstantProperty.js';
import HeightReference from '../../../Scene/HeightReference.js';
import Cartesian3 from '../../../Core/Cartesian3.js';
import Cartesian2 from '../../../Core/Cartesian2.js';
import Color from '../../../Core/Color.js';
import PolylineDashMaterialProperty from '../../../DataSources/PolylineDashMaterialProperty.js';
import LabelStyle from '../../../Scene/LabelStyle.js';
import PolygonGraphics from '../../../DataSources/PolygonGraphics.js';
import EllipsoidGeodesic from '../../../Core/EllipsoidGeodesic.js';
import EllipseGeometryLibrary from '../../../Core/EllipseGeometryLibrary.js';
import buildModuleUrl from '../../../Core/buildModuleUrl.js';
import PolylineGlowMaterialProperty from '../../../DataSources/PolylineGlowMaterialProperty.js';
import Rectangle from '../../../Core/Rectangle.js';
import PolylineArrowMaterialProperty from '../../../DataSources/PolylineArrowMaterialProperty.js';
import ClassificationType from '../../../Scene/ClassificationType.js';
import DistanceDisplayCondition from '../../../Core/DistanceDisplayCondition.js';
function DTDrawFuncTool(){}
//显示圆
DTDrawFuncTool.showCircle=function(objId, positions,dtDraw,options) {
    var pnts = dtDraw._tracker._circleDrawer._computeCirclePolygon(positions);
    //控制是否显示
    if (options.show) {
        if (dtDraw._editing) {
            dtDraw._editing=false;
        }
        var material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        var outlineMaterial = new PolylineDashMaterialProperty({
            dashLength: 16,
            color: Color.fromCssColorString('#f00').withAlpha(0.7)
        });
        var radiusMaterial = new PolylineDashMaterialProperty({
            dashLength: 16,
            color: Color.fromCssColorString('#00f').withAlpha(0.7)
        });
        var dis = dtDraw._tracker._circleDrawer._computeCircleRadius3D(positions);
        dis = (dis / 1000).toFixed(3);
        var text = dis + "km";
        var bData = {
            layerId: dtDraw._layerId,
            objId: objId,
            shapeType: "Circle",
            position: positions[0],
            label: {
                text: text,
                font: '16px Helvetica',
                fillColor: Color.SKYBLUE,
                outlineColor: Color.BLACK,
                outlineWidth: 1,
                style: LabelStyle.FILL_AND_OUTLINE,
                eyeOffset: new ConstantProperty(new Cartesian3(0, 0, 0)),
                pixelOffset: new Cartesian2(16, 16)
            },
            billboard: {
                image: buildModuleUrl('Assets/Images/circle_center.png'),
                eyeOffset: new ConstantProperty(new Cartesian3(0, 0, 0)),
                heightReference: HeightReference.CLAMP_TO_GROUND
            },
            polyline: {
                positions: positions,
                clampToGround: true,
                width: 2,
                material: radiusMaterial
            },
            polygon: new PolygonGraphics({
                hierarchy: pnts,
                asynchronous: false,
                material: material
            })
        };
        var entity = dtDraw._viewer.entities.add(bData);
        var outlineBdata = {
            layerId: dtDraw._layerId,
            objId: objId,
            shapeType: "Circle",
            polyline: {
                positions: pnts,
                clampToGround: true,
                width: 2,
                material: outlineMaterial
            }
        };
        var outlineEntity = dtDraw._viewer.entities.add(outlineBdata);
    }
    //执行回调函数
    if (defined(options.callback)) {
       options.callback(pnts,options.parameters)
    }
    entity.callbackAndParams={
        callback:options.callback!=undefined?options.callback:undefined,
        params:options.parameters!=undefined?options.parameters:undefined
    }
}
//显示多边形
DTDrawFuncTool.showPolygon=function(objId, positions,dtDraw,options) {
    var entity=undefined;
    if (options.show) {
        if (dtDraw._editing) {
            dtDraw._editing=false;
        }
        var material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        var outlineMaterial = new PolylineDashMaterialProperty({
            dashLength: 16,
            color: Color.fromCssColorString('#00f').withAlpha(0.7)
        });
        var outlinePositions = [].concat(positions);
        outlinePositions.push(positions[0]);
        var bData = {
            layerId: dtDraw._layerId,
            objId: objId,
            shapeType: "Polygon",
            polyline: {
                positions: outlinePositions,
                clampToGround: true,
                width: 2,
                material: outlineMaterial
            },
            polygon: new PolygonGraphics({
                hierarchy: positions,
                asynchronous: false,
                material: material
            })
        };
        entity = dtDraw._viewer.entities.add(bData);
    }
    //执行回调函数
    if (defined(options.callback)) {
        options.callback(positions,options.parameters,objId)//lmw add entity回传
    }
    //挂载回调函数与参数

    //lmw add 为了区分是否修改
    if(options.parameters.isUpdateCall===undefined){
        options.parameters.isUpdateCall=true;
    }

    entity.callbackAndParams={
        callback:options.callback!=undefined?options.callback:undefined,
        params:options.parameters!=undefined?options.parameters:undefined
    }
}
//显示点
DTDrawFuncTool.showPoint=function(objId, position,dtDraw,options) {
    if (options.show) {
        if (dtDraw._editing) {
            dtDraw._editing=false;
        }
        var entity = dtDraw._viewer.entities.add({
            layerId: 'drawGeometry',
            objId: objId,
            shapeType: "Point",
            position: position,
            billboard: {
                image:buildModuleUrl("/Source/Assets/Images/circle_red.png"),
                eyeOffset: new ConstantProperty(new Cartesian3(0, 0, 0)),
                heightReference:HeightReference.CLAMP_TO_GROUND,
                color:Color.CRIMSON,
                distanceDisplayCondition:new DistanceDisplayCondition(0,100000)
            }
        });
    }
    //执行回调函数
    if (defined(options.callback)) {
        options.callback(position,options.parameters)
    }
    //挂载回调函数与参数
    entity.callbackAndParams={
        callback:options.callback!=undefined?options.callback:undefined,
        params:options.parameters!=undefined?options.parameters:undefined
    }
}
//显示矩形
DTDrawFuncTool.showRectangle=function(objId, positions,dtDraw,options) {
    var rect = Rectangle.fromCartesianArray(positions);
    var arr = [rect.west, rect.north, rect.east, rect.north, rect.east, rect.south, rect.west, rect.south, rect.west, rect.north];
    var outlinePositions = Cartesian3.fromRadiansArray(arr);
    if (options.show) {
        if (dtDraw._editing) {
            dtDraw._editing=false;
        }
        var material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        var outlineMaterial = new PolylineDashMaterialProperty({
            dashLength: 16,
            color: Color.fromCssColorString('#00f').withAlpha(0.7)
        });
        var bData = {
            layerId: dtDraw._layerId,
            objId: objId,
            shapeType: "Rectangle",
            polyline: {
                positions: outlinePositions,
                clampToGround: true,
                width: 2,
                material: outlineMaterial
            },
            rectangle: {
                coordinates: rect,
                material: material
            }
        };
        var entity = dtDraw._viewer.entities.add(bData);
    }
    //执行回调函数
    if (defined(options.callback)) {
        options.callback(outlinePositions,options.parameters)
    }
    //挂载回调函数与参数
    entity.callbackAndParams={
        callback:options.callback!=undefined?options.callback:undefined,
        params:options.parameters!=undefined?options.parameters:undefined
    }
}
//显示折线
DTDrawFuncTool.showPolyline=function(objId, positions,dtDraw,options) {
    if (options.show) {
        if (dtDraw._editing) {
            dtDraw._editing=false;
        }
        var material = new PolylineGlowMaterialProperty({
            glowPower: 0.25,
            color: Color.fromCssColorString('#00f').withAlpha(0.9)
        });
        var bData = {
            layerId: dtDraw._layerId,
            objId: objId,
            shapeType: "Polyline",
            polyline: {
                positions: positions,
                clampToGround: true,
                width: 8,
                material: material
            }
        };
        var entity = dtDraw._viewer.entities.add(bData);
    }
    //执行回调函数
    if (defined(options.callback)) {
        options.callback(positions,options.parameters)
    }
    //挂载回调函数与参数
    entity.callbackAndParams={
        callback:options.callback!=undefined?options.callback:undefined,
        params:options.parameters!=undefined?options.parameters:undefined
    }
}
//显示进攻箭头
DTDrawFuncTool.showAttackArrow=function(objId, positions,dtDraw,options) {
    if (options.show) {
        if (dtDraw._editing) {
            dtDraw._editing=false;
        }
        var material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        var outlineMaterial = new PolylineDashMaterialProperty({
            dashLength: 16,
            color: Color.fromCssColorString('#f00').withAlpha(0.7)
        });
        var outlinePositions = [].concat(positions);
        outlinePositions.push(positions[0]);
        var bData = {
            layerId: dtDraw._layerId,
            objId: objId,
            shapeType: "AttackArrow",
            polyline: {
                positions: outlinePositions,
                clampToGround: true,
                width: 2,
                material: outlineMaterial
            },
            polygon: new PolygonGraphics({
                hierarchy: positions,
                asynchronous: false,
                material: material
            })
        };
        var entity = dtDraw._viewer.entities.add(bData);
    }
    //执行回调函数
    if (defined(options.callback)) {
        options.callback(positions,options.parameters)
    }
    //挂载回调函数与参数
    entity.callbackAndParams={
        callback:options.callback!=undefined?options.callback:undefined,
        params:options.parameters!=undefined?options.parameters:undefined
    }
}
//显示折线箭头
DTDrawFuncTool.showStraightArrow=function(objId, positions,dtDraw,options) {
    if (options.show) {
        if (dtDraw._editing) {
            dtDraw._editing=false;
        }
        var material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        var outlineMaterial = new PolylineDashMaterialProperty({
            dashLength: 16,
            color: Color.fromCssColorString('#f00').withAlpha(0.7)
        });
        var outlinePositions = [].concat(positions);
        outlinePositions.push(positions[0]);
        var bData = {
            layerId: dtDraw._layerId,
            objId: objId,
            shapeType: "StraightArrow",
            polyline: {
                positions: outlinePositions,
                clampToGround: true,
                width: 2,
                material: outlineMaterial
            },
            polygon: new PolygonGraphics({
                hierarchy: positions,
                asynchronous: false,
                material: material
            })
        };
        var entity = dtDraw._viewer.entities.add(bData);
    }
    //执行回调函数
    if (defined(options.callback)) {
        options.callback(positions,options.parameters)
    }
    //挂载回调函数与参数
    entity.callbackAndParams={
        callback:options.callback!=undefined?options.callback:undefined,
        params:options.parameters!=undefined?options.parameters:undefined
    }
}
//显示夹击箭头
DTDrawFuncTool.showPincerArrow=function(objId, positions,dtDraw,options) {
    if (options.show) {
        if (dtDraw._editing) {
            dtDraw._editing=false;
        }
        var material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        var outlineMaterial = new PolylineDashMaterialProperty({
            dashLength: 16,
            color: Color.fromCssColorString('#f00').withAlpha(0.7)
        });
        var outlinePositions = [].concat(positions);
        outlinePositions.push(positions[0]);
        var bData = {
            layerId: dtDraw._layerId,
            objId: objId,
            shapeType: "PincerArrow",
            polyline: {
                positions: outlinePositions,
                clampToGround: true,
                width: 2,
                material: outlineMaterial
            },
            polygon: new PolygonGraphics({
                hierarchy: positions,
                asynchronous: false,
                material: material
            })
        };
        var entity = dtDraw._viewer.entities.add(bData);
    }
    //执行回调函数
    if (defined(options.callback)) {
        options.callback(positions,options.parameters)
    }
    //挂载回调函数与参数
    entity.callbackAndParams={
        callback:options.callback!=undefined?options.callback:undefined,
        params:options.parameters!=undefined?options.parameters:undefined
    }
}
//编辑圆
DTDrawFuncTool.editCircle=function(objId,dtDraw) {
    var oldPositions = dtDraw._shapeDic[objId];
    let options={
        show:true,
        callback:dtDraw._callback,
        parameters:dtDraw._callbackParams
    }
    //先移除entity
    DTDrawFuncTool.clearEntityById(objId,dtDraw);
    //进入编辑状态
    dtDraw._tracker._circleDrawer.showModifyCircle(oldPositions, function (positions) {
        dtDraw._shapeDic[objId] = positions;
        DTDrawFuncTool.showCircle(objId, positions,dtDraw,options);
    }, function () {
        DTDrawFuncTool.showCircle(objId, oldPositions,dtDraw,options);
    });
}
//编辑点
DTDrawFuncTool.editPoint=function(objId,dtDraw) {
    let options={
        show:true,
        callback:dtDraw._callback,
        parameters:dtDraw._callbackParams
    }
    var oldPosition = dtDraw._shapeDic[objId];
    //先移除entity
    DTDrawFuncTool.clearEntityById(objId,dtDraw);
    //进入编辑状态
    dtDraw._tracker._pointDrawer.showModifyPoint(oldPosition, function (position) {
        dtDraw._shapeDic[objId] = position;
        DTDrawFuncTool.showPoint(objId, position,dtDraw,options);
    }, function () {
        DTDrawFuncTool.showPoint(objId, oldPosition,dtDraw,options);
    });
}
//编辑矩形
DTDrawFuncTool.editRectangle=function(objId,dtDraw) {
    let options={
        show:true,
        callback:dtDraw._callback,
        parameters:dtDraw._callbackParams
    }
    var oldPositions = dtDraw._shapeDic[objId];
    //先移除entity
    DTDrawFuncTool.clearEntityById(objId,dtDraw);
    //进入编辑状态
    dtDraw._tracker._rectDrawer.showModifyRectangle(oldPositions, function (positions) {
        dtDraw._shapeDic[objId] = positions;
        DTDrawFuncTool.showRectangle(objId, positions,dtDraw,options);
    }, function () {
        DTDrawFuncTool.showRectangle(objId, oldPositions,dtDraw,options);
    });
}
//编辑折线
DTDrawFuncTool.editPolyline=function(objId,dtDraw) {
    let options={
        show:true,
        callback:dtDraw._callback,
        parameters:dtDraw._callbackParams
    }
    var oldPositions = dtDraw._shapeDic[objId];
    //先移除entity
    DTDrawFuncTool.clearEntityById(objId,dtDraw);
    //进入编辑状态
    dtDraw._tracker._polylineDrawer.showModifyPolyline(oldPositions, function (positions) {
        dtDraw._shapeDic[objId] = positions;
        DTDrawFuncTool.showPolyline(objId, positions,dtDraw,options);
    }, function () {
        DTDrawFuncTool.showPolyline(objId, oldPositions,dtDraw,options);
    });
}
//编辑进攻箭头
DTDrawFuncTool.editAttackArrow=function(objId,dtDraw) {
    let options={
        show:true,
        callback:dtDraw._callback,
        parameters:dtDraw._callbackParams
    }
    var old = dtDraw._shapeDic[objId];
    //先移除entity
    DTDrawFuncTool.clearEntityById(objId,dtDraw);
    dtDraw._tracker._attackArrowDrawer.showModifyAttackArrow(old.custom, function (positions, custom) {
        //保存编辑结果
        dtDraw._shapeDic[objId] = {
            custom: custom,
            positions: positions
        };
        DTDrawFuncTool.showAttackArrow(objId, positions,dtDraw,options);
    }, function () {
        DTDrawFuncTool.showAttackArrow(objId, old.positions,dtDraw,options);
    });
}
//编辑直线箭头
DTDrawFuncTool.editStraightArrow=function(objId,dtDraw) {
    let options={
        show:true,
        callback:dtDraw._callback,
        parameters:dtDraw._callbackParams
    }
    var oldPositions = dtDraw._shapeDic[objId];
    //先移除entity
    DTDrawFuncTool.clearEntityById(objId,dtDraw);
    //进入编辑状态
    dtDraw._tracker._straightArrowDrawer.showModifyStraightArrow(oldPositions, function (positions) {
        dtDraw._shapeDic[objId] = positions;
        DTDrawFuncTool.showStraightArrow(objId, positions,dtDraw,options);
    }, function () {
        DTDrawFuncTool.showStraightArrow(objId, oldPositions,dtDraw,options);
    });
}
//编辑夹击箭头
DTDrawFuncTool.editPincerArrow=function(objId,dtDraw) {
    let options={
        show:true,
        callback:dtDraw._callback,
        parameters:dtDraw._callbackParams
    }
    var old = dtDraw._shapeDic[objId];
    //先移除entity
    DTDrawFuncTool.clearEntityById(objId,dtDraw);
    dtDraw._tracker._pincerArrowDrawer.showModifyPincerArrow(old.custom, function (positions, custom) {
        //保存编辑结果
        dtDraw._shapeDic[objId] = {
            custom: custom,
            positions: positions
        };
        DTDrawFuncTool.showPincerArrow(objId, positions,dtDraw,options);
    }, function () {
        DTDrawFuncTool.showPincerArrow(objId, old.positions,dtDraw,options);
    });
}
//编辑多边形
DTDrawFuncTool.editPolygon=function(objId,dtDraw) {
    let options={
        show:true,
        callback:dtDraw._callback,
        parameters:dtDraw._callbackParams
    }
    var oldPositions = dtDraw._shapeDic[objId];
    //先移除entity
    DTDrawFuncTool.clearEntityById(objId,dtDraw);
    //进入编辑状态
    dtDraw._tracker._polygonDrawer.showModifyPolygon(oldPositions, function (positions) {
        dtDraw._shapeDic[objId] = positions;
        DTDrawFuncTool.showPolygon(objId, positions,dtDraw,options);
    }, function () {
        DTDrawFuncTool.showPolygon(objId, oldPositions,dtDraw,options);
    });
}
//删除所有geometry,绘制或者编辑之前调用
DTDrawFuncTool.clearEntityById=function(objId,dtDraw) {
    var entityList = dtDraw._viewer.entities.values;
    if (entityList == null || entityList.length < 1) {
        return;
    }
    for (var i = 0; i < entityList.length; i++) {
        var entity = entityList[i];
        if (entity.layerId == dtDraw._layerId && entity.objId == objId) {
            dtDraw._viewer.entities.remove(entity);
            i--;
        }
    }
}
export default DTDrawFuncTool;
