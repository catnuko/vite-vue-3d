import DTCircleDrawer from './DTCircleDrawer.js';
import DTPolygonDrawer from './DTPolygonDrawer.js';
import DTPointDrawer from './DTPointDrawer.js';
import DTRectangleDrawer from './DTRectangleDrawer.js';
import DTPolylineDrawer from './DTPolylineDrawer.js';
import DTPlotAttackArrowDrawer from './DTPlotAttackArrowDrawer.js';
import DTPlotStraightArrowDrawer from './DTPlotStraightArrowDrawer.js';
import DTPlotPincerArrowDrawer from './DTPlotPincerArrowDrawer.js';
import defined from '../../../Core/defined.js';
/**
 * @alias DTTracker
 * @constructor
 * @description DTTracker集成绘制点、线、面、以及军事图标等绘制功能
 * @param {Viewer} [viewer] Viewer实例对象:
 */
    function DTTracker (viewer){
        this._viewer=viewer;
        this._ctrArr=[];
        this._circleDrawer=null;
        this._polygonDrawer=null;
        this._pointDrawer=null;
        this._rectDrawer =null;
        this._polylineDrawer=null;
        this._attackArrowDrawer =null;
        this._straightArrowDrawer =null;
        this._pincerArrowDrawer =null;
        this.Init(viewer);
    }
    Object.defineProperties(DTTracker.prototype, {
     /**
     * viewer实例对象
     * @memberof DTTracker.prototype
     * @type {Object}
     */
        viewer: {
            get: function () {
                return this._viewer;
            }
        },
        /**
         * 圆绘制实例对象
         * @memberof DTTracker.prototype
         * @type {Object}
         */
        circleDrawer: {
            get: function () {
                return this._circleDrawer;
            }
        },
        /**
         * 多边形绘制实例对象
         * @memberof DTTracker.prototype
         * @type {Object}
         */
        polygonDrawer: {
            get: function () {
                return this._polygonDrawer;
            }
        },
        /**
         * 点绘制实例对象
         * @memberof DTTracker.prototype
         * @type {Object}
         */
        pointDrawer: {
            get: function () {
                return this._pointDrawer;
            }
        },
         /**
         * 矩形绘制实例对象
         * @memberof DTTracker.prototype
         * @type {Object}
         */
        rectDrawer: {
            get: function () {
                return this._rectDrawer;
            }
        },
         /**
         * 折线绘制实例对象
         * @memberof DTTracker.prototype
         * @type {Object}
         */
        polylineDrawer: {
            get: function () {
                return this._polylineDrawer;
            }
        },
         /**
         * 攻击箭头绘制实例对象
         * @memberof DTTracker.prototype
         * @type {Object}
         */
        attackArrowDrawer: {
            get: function () {
                return this._attackArrowDrawer;
            }
        },
         /**
         * 直线箭头绘制实例对象
         * @memberof DTTracker.prototype
         * @type {Object}
         */
        straightArrowDrawer: {
            get: function () {
                return this._straightArrowDrawer;
            }
        },
         /**
         * 夹击箭头绘制实例对象
         * @memberof DTTracker.prototype
         * @type {Object}
         */
        pincerArrowDrawer: {
            get: function () {
                return this._pincerArrowDrawer;
            }
        }
    })
    /**
     * 绘制圆
     * @param {Function} okHandler 生成circle对象函数
     * @param {Function} cancelHandler 取消生成circle对象函数
     */
    DTTracker.prototype.trackCircle=function (okHandler, cancelHandler) {
        this.clear();
        if (this._circleDrawer == null) {
            this._circleDrawer = new DTCircleDrawer(this._viewer);
            this._ctrArr.push(this._circleDrawer);
        }

        this._circleDrawer.startDrawCircle(okHandler, cancelHandler);
    }
    /**
     * 绘制多边形
     * @param {Function} okHandler 生成polygon对象函数
     * @param {Function} cancelHandler 取消生成polygon对象函数
     */
    DTTracker.prototype.trackPolygon=function (okHandler, cancelHandler) {
        this.clear();
        if (this._polygonDrawer == null) {
            this._polygonDrawer=new DTPolygonDrawer(this._viewer);
            this._ctrArr.push(this._polygonDrawer);
        }
        this._polygonDrawer.startDrawPolygon(okHandler, cancelHandler);
    }
    /**
     * 绘制点
     * @param {Function} okHandler 生成point对象函数
     * @param {Function} cancelHandler 取消生成point对象函数
     */
    DTTracker.prototype.trackPoint=function (okHandler, cancelHandler) {
        this.clear();
        if (this._pointDrawer == null) {
            this._pointDrawer = new DTPointDrawer(this._viewer);
            this.ctrArr.push(this._pointDrawer);
        }
        this._pointDrawer.startDrawPoint(okHandler, cancelHandler);
    }
    /**
     * 绘制矩形
     * @param {Function} okHandler 生成rectangle对象函数
     * @param {Function} cancelHandler 取消生成rectangle对象函数
     */
    DTTracker.prototype.trackRectangle=function (okHandler, cancelHandler) {
        this.clear();
        if (this._rectDrawer == null) {
            this._rectDrawer = new DTRectangleDrawer(this._viewer);
            this._ctrArr.push(this._rectDrawer);
        }

        this._rectDrawer.startDrawRectangle(okHandler, cancelHandler);
    }
     /**
     * 绘制折线
     * @param {Function} okHandler 生成polyline对象函数
     * @param {Function} cancelHandler 取消生成polyline对象函数
     */
    DTTracker.prototype.trackPolyline=function (okHandler, cancelHandler) {
        this.clear();
        if (this._polylineDrawer == null) {
            this._polylineDrawer = new DTPolylineDrawer(this._viewer);
            this._ctrArr.push(this._polylineDrawer);
        }
        this._polylineDrawer.startDrawPolyline(okHandler, cancelHandler);
    }
     /**
     * 绘制进攻箭头
     * @param {Function} okHandler 生成attackArrow对象函数
     * @param {Function} cancelHandler 取消生成attackArrow对象函数
     */
    DTTracker.prototype.trackAttackArrow=function (okHandler, cancelHandler) {
        this.clear();
        if (this._attackArrowDrawer == null) {
            this._attackArrowDrawer = new DTPlotAttackArrowDrawer(this._viewer);
            this._ctrArr.push(this._attackArrowDrawer);
        }
        this._attackArrowDrawer.startDrawAttackArrow(okHandler, cancelHandler);
    }
     /**
     * 绘制直线箭头
     * @param {Function} okHandler 生成straightArrow对象函数
     * @param {Function} cancelHandler 取消生成straightArrow对象函数
     */
    DTTracker.prototype.trackStraightArrow=function (okHandler, cancelHandler) {
        this.clear();
        if (this._straightArrowDrawer == null) {
            this._straightArrowDrawer = new DTPlotStraightArrowDrawer(this._viewer);
            this._ctrArr.push(this._straightArrowDrawer);
        }
        this._straightArrowDrawer.startDrawStraightArrow(okHandler, cancelHandler);
    }
    /**
     * 绘制夹击箭头
     * @param {Function} okHandler 生成pincerArrow对象函数
     * @param {Function} cancelHandler 取消生成pincerArrow对象函数
     */
    DTTracker.prototype.trackPincerArrow=function (okHandler, cancelHandler) {
        this.clear();
        if (this._pincerArrowDrawer == null) {
            this._pincerArrowDrawer = new DTPlotPincerArrowDrawer(this._viewer);
            this._ctrArr.push(this._pincerArrowDrawer);
        }
        this._pincerArrowDrawer.startDrawPincerArrow(okHandler, cancelHandler);
    }
    //私有方法
    DTTracker.prototype.clear=function () {
        for (var i = 0; i < this._ctrArr.length; i++) {
            var ctr = this._ctrArr[i];
            if (ctr.clear) {
                ctr.clear();
            }
        }
    }
    //私有方法
    DTTracker.prototype.Init=function(viewer){
        this._circleDrawer = new DTCircleDrawer(viewer);
        this._circleDrawer.executeHandlerType="okHandler";
        this._ctrArr.push(this._circleDrawer);
        this._polygonDrawer=new DTPolygonDrawer(viewer);
        this._ctrArr.push(this._polygonDrawer);
        this._pointDrawer = new DTPointDrawer(viewer);
        this._ctrArr.push(this._pointDrawer);
        this._rectDrawer = new DTRectangleDrawer(viewer);
        this._ctrArr.push(this._rectDrawer);
        this._polylineDrawer = new DTPolylineDrawer(viewer);
        this._ctrArr.push(this._polylineDrawer);
        this._attackArrowDrawer = new DTPlotAttackArrowDrawer(viewer);
        this._ctrArr.push(this._attackArrowDrawer);
        this._straightArrowDrawer = new DTPlotStraightArrowDrawer(viewer);
        this._ctrArr.push(this._straightArrowDrawer);
        this._pincerArrowDrawer = new DTPlotPincerArrowDrawer(viewer);
        this._ctrArr.push(this._pincerArrowDrawer);
    }
    //设置结束编辑的方式
    DTTracker.prototype.setEndDrawWay=function(endDrawWay){
        let drawHandles=this._ctrArr;
        drawHandles.forEach(element => {
            element.rightClickEndDraw=endDrawWay;
        });
    }
    //设置获取坐标的方式
    DTTracker.prototype.setCartWay=function(CartWay){
        let drawHandles=this._ctrArr;
        drawHandles.forEach(element => {
            if (defined(element._getCartWay)) {
                element._getCartWay=CartWay;
            }
        });
    }
export default DTTracker;
