import DTTooltip from './DTTooltip.js';
import ScreenSpaceEventHandler from '../../../Core/ScreenSpaceEventHandler.js';
import defined from '../../../Core/defined.js';
import ScreenSpaceEventType from '../../../Core/ScreenSpaceEventType.js';
import ConstantProperty from '../../../DataSources/ConstantProperty.js';
import HeightReference from '../../../Scene/HeightReference.js';
import Cartesian3 from '../../../Core/Cartesian3.js';
import Cartesian2 from '../../../Core/Cartesian2.js';
import Color from '../../../Core/Color.js';
import PolylineDashMaterialProperty from '../../../DataSources/PolylineDashMaterialProperty.js';
import CallbackProperty from '../../../DataSources/CallbackProperty.js';
import LabelStyle from '../../../Scene/LabelStyle.js';
import PolygonGraphics from '../../../DataSources/PolygonGraphics.js';
import EllipsoidGeodesic from '../../../Core/EllipsoidGeodesic.js';
import EllipseGeometryLibrary from '../../../Core/EllipseGeometryLibrary.js';
import buildModuleUrl from '../../../Core/buildModuleUrl.js';
import algorithm from './algorithm.js';
import Math from '../../../Core/Math.js';
import SceneTransforms from '../../../Scene/SceneTransforms.js';
import DistanceDisplayCondition from '../../../Core/DistanceDisplayCondition.js'
    /**
     * @alias DTPointDrawer
     * @constructor
     * @description DTPointDrawer点绘制类
     * @param {Viewer} [viewer] Viewer实例对象:
     */
    function DTPointDrawer(viewer) {
        this._viewer = viewer;
        this._scene = viewer.scene;
        this._clock = viewer.clock;
        this._canvas = viewer.scene.canvas;
        this._camera = viewer.scene.camera;
        this._ellipsoid = viewer.scene.globe.ellipsoid;
        this._tooltip = new DTTooltip(viewer.container);
        this._entity = null;
        this._position = null;
        this._drawHandler = null;
        this._modifyHandler = null;
        this._okHandler = null;
        this._cancelHandler = null;
        this._image = buildModuleUrl("Assets/Images/circle_red.png");
        this._layerId = "globeEntityDrawerLayer";
        this._rightClickEndDraw=true;//新增是否右键结束绘制
    }
    Object.defineProperties(DTPointDrawer.prototype, {
         /**
         * viewer实例对象
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        viewer: {
            get: function () {
                return this._viewer;
            }
        },
        /**
         * scene实例对象
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        scene: {
            get: function () {
                return this._scene;
            }
        },
         /**
         * clock实例对象
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        clock: {
            get: function () {
                return this._clock;
            }
        },
        /**
         * canvas实例对象
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        canvas: {
            get: function () {
                return this._canvas;
            }
        },
        /**
         * camera实例对象
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        camera: {
            get: function () {
                return this._camera;
            }
        },
        /**
         * ellipsoid实例对象
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        ellipsoid: {
            get: function () {
                return this._ellipsoid;
            }
        },
        /**
         * tooltip实例对象
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        tooltip: {
            get: function () {
                return this._tooltip;
            }
        },
        /**
         * 当前绘制点的实例
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        entity: {
            get: function () {
                return this._entity;
            },
            set: function (value) {
                this._entity = value
            }
        },
        /**
         * 当前绘制点的实例
         * @memberof DTPointDrawer.prototype
         * @type {Array}
         */
        position: {
            get: function () {
                return this._positions;
            },
            set: function (value) {
                this._positions = value
            }
        },
        /**
         * 点的绘制的Handler
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        drawHandler: {
            get: function () {
                return this._drawHandler;
            },
            set: function (value) {
                this._drawHandler = value
            }
        },
         /**
         * 点的编辑的Handler
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        modifyHandler: {
            get: function () {
                return this._modifyHandler;
            },
            set: function (value) {
                this._modifyHandler = value
            }
        },
         /**
         * 生成点的回调函数，也可以仅仅获取点
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        okHandler: {
            get: function () {
                return this._okHandler;
            },
            set: function (value) {
                this._okHandler = value
            }
        },
        /**
         * 取消生成多边形的回调函数
         * @memberof DTPointDrawer.prototype
         * @type {Object}
         */
        cancelHandler: {
            get: function () {
                return this._cancelHandler;
            },
            set: function (value) {
                this._cancelHandler = value
            }
        },
        /**
         * 标识entity
         * @memberof DTPointDrawer.prototype
         * @type {String}
         */
        layerId: {
            get: function () {
                return this._layerId;
            }
        },
        /**
         * 操作类型
         * @memberof DTPointDrawer.prototype
         * @type {String}
         */
        executeHandlerType: {
            get: function () {
                return this._executeHandlerType;
            },
            set: function (value) {
                this._executeHandlerType = value
            }
        },
        //暂留
        rightClickEndDraw:{
            get:function(){
               return this._rightClickEndDraw;
            },
            set:function(value){
              this._rightClickEndDraw=value;
            }
        }
    })
    /**
     * 绘制命令销毁，并不是类的销毁
     */
    DTPointDrawer.prototype.clear = function () {
        if (this.drawHandler) {
            this.drawHandler.destroy();
            this.drawHandler = null;
        }
        if (this.modifyHandler) {
            this.modifyHandler.destroy();
            this.modifyHandler = null;
        }
        clearMarkers(this, this.layerId);
        this.tooltip.setVisible(false);
    }
    /**
     * 绘制成功结束后的回调函数
     */
    DTPointDrawer.prototype.excuteOkHandler = function () {
        this.clear();
        if (this.okHandler) {
            this.okHandler(this.position);
        }

    }
    /**
     * 取消绘制结果的回调函数
     */
    DTPointDrawer.prototype.excuteCancelHandler = function () {
        this.clear();
        if (this.cancelHandler) {
            this.cancelHandler();
        }
    }
    /**
     * 显示绘制的geometry,用户无需调用
     */
    DTPointDrawer.prototype.showModifyPoint = function (position, okHandler, cancelHandler) {
        var _this = this;
        _this.position = position;
        _this.okHandler = okHandler;
        _this.cancelHandler = cancelHandler;
        //弹出diglog
        //this.tooltip.dialogShowAt(SceneTransforms.wgs84ToWindowCoordinates(this._scene,_this.position), _this);
        _this.entity = null;
        createPoint(_this);
        startModify(_this);
    }
    /**
     * 绘制点的命令，单独使用此类，可调用该方法进行绘制点
     * @param {Function} okHandler 生成点对象回调函数
     * @param {Function} cancelHandler 取消生成点对象函数
     */
    DTPointDrawer.prototype.startDrawPoint = function (okHandler, cancelHandler) {
        var _this = this;
        _this.okHandler = okHandler;
        _this.cancelHandler = cancelHandler;
        _this.entity = null;
        _this.position = null;
        var isShow = true;
        var floatingPoint = null;
        _this.drawHandler = new ScreenSpaceEventHandler(_this.canvas);

        _this.drawHandler.setInputAction(function (event) {
            var wp = event.position;
            if (!defined(wp)) {
                return;
            }
            var ray = _this.camera.getPickRay(wp);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            _this.position = cartesian;
            isShow = false
            _this.entity.position.setValue(cartesian);
            _this.tooltip.setVisible(false);
            startModify(_this);
            ///新增结束
            _this.excuteOkHandler();
        }, ScreenSpaceEventType.LEFT_CLICK);

        _this.drawHandler.setInputAction(function (event) {
            var wp = event.endPosition;
            if (!defined(wp)) {
                return;
            }
            if (isShow) {
                _this.tooltip.showAt(wp, "<p>选择位置</p>");
            }
            var ray = _this.camera.getPickRay(wp);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            _this.position = cartesian;
            if (_this.entity == null) {
                _this._image = buildModuleUrl("Assets/Images/circle_red.png");
                createPoint(_this);
            } else {
                _this.entity.position.setValue(cartesian);
            }
        }, ScreenSpaceEventType.MOUSE_MOVE);
    }
    //编辑点调用，属于内部函数
    function startModify(that) {
        var _this = that;
        var isMoving = false;
        var pickedAnchor = null;
        if (_this.drawHandler) {
            _this.drawHandler.destroy();
            _this.drawHandler = null;
        }
        _this.modifyHandler = new ScreenSpaceEventHandler(_this.canvas);

        _this.modifyHandler.setInputAction(function (event) {
            var wp = event.position;
            if (!defined(wp)) {
                return;
            }
            var ray = _this.camera.getPickRay(wp);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            if (isMoving) {
                isMoving = false;
                pickedAnchor.position.setValue(cartesian);
                var oid = pickedAnchor.oid;
                _this.position = cartesian;
                _this.tooltip.setVisible(false);
                ///新增结束
                _this.excuteOkHandler();
            } else {
                var pickedObject = _this.scene.pick(wp);
                if (!defined(pickedObject)) {
                    return;
                }
                if (!defined(pickedObject.id)) {
                    return;
                }
                var entity = pickedObject.id;
                if (entity.layerId != _this.layerId || entity.flag != "anchor") {
                    return;
                }
                pickedAnchor = entity;
                isMoving = true;
                _this.tooltip.showAt(wp, "<p>移动位置</p>");
            }
        }, ScreenSpaceEventType.LEFT_CLICK);

        _this.modifyHandler.setInputAction(function (event) {
            if (!isMoving) {
                return;
            }
            var wp = event.endPosition;
            if (!defined(wp)) {
                return;
            }
            _this.tooltip.showAt(wp, "<p>移动位置</p>");

            var ray = _this.camera.getPickRay(wp);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            pickedAnchor.position.setValue(cartesian);
            var oid = pickedAnchor.oid;
            _this.position = cartesian;
        }, ScreenSpaceEventType.MOUSE_MOVE);
    }
    //创建端点提示点
    function createPoint(that) {
        var _this = that;
        var point = _this.viewer.entities.add({
            position: _this.position,
            billboard: {
                image: _this._image,
                eyeOffset: new ConstantProperty(new Cartesian3(0, 0, 0)),
                heightReference: HeightReference.CLAMP_TO_GROUND,
                color:Color.CRIMSON,
            }
        });
        point.oid = 0;
        point.layerId = _this.layerId;
        point.flag = "anchor";
        _this.entity = point;
        return point;
    }
    //世界坐标转经纬度坐标
    function getLonLat(that, cartesian) {
        var _this = that;
        var cartographic = _this.ellipsoid.cartesianToCartographic(cartesian);
        cartographic.height = _this.viewer.scene.globe.getHeight(cartographic);
        var pos = {
            lon: cartographic.longitude,
            lat: cartographic.latitude,
            alt: cartographic.height,
            height: cartographic.height
        };
        pos.lon = Math.toDegrees(pos.lon);
        pos.lat = Math.toDegrees(pos.lat);
        return pos;
    }
    //清空所有端点提示点
    function clearMarkers(that, layerName) {
        var _this = that;
        var viewer = _this.viewer;
        var entityList = viewer.entities.values;
        if (entityList == null || entityList.length < 1)
            return;
        for (var i = 0; i < entityList.length; i++) {
            var entity = entityList[i];
            if (entity.layerId == layerName) {
                viewer.entities.remove(entity);
                i--;
            }
        }
    }
    //暂留方法
    function executeHandler(that) {
        if (that.executeHandlerType != null) {
            if (that.executeHandlerType == "okHandler") {
                that.okHandler(that.positions);
            } else {
                that.cancelHandler();
            }
            that.executeHandlerType = null;
        }
    }
export default DTPointDrawer;
