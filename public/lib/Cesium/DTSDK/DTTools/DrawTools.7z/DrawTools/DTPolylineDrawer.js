import DTTooltip from './DTTooltip.js';
import ScreenSpaceEventHandler from '../../../Core/ScreenSpaceEventHandler.js';
import defined from '../../../Core/defined.js';
import ScreenSpaceEventType from '../../../Core/ScreenSpaceEventType.js';
import ConstantProperty from '../../../DataSources/ConstantProperty.js';
import HeightReference from '../../../Scene/HeightReference.js';
import Cartesian3 from '../../../Core/Cartesian3.js';
import Cartesian2 from '../../../Core/Cartesian2.js';
import Color from '../../../Core/Color.js';
import PolylineDashMaterialProperty from '../../../DataSources/PolylineDashMaterialProperty.js';
import CallbackProperty from '../../../DataSources/CallbackProperty.js';
import LabelStyle from '../../../Scene/LabelStyle.js';
import PolygonGraphics from '../../../DataSources/PolygonGraphics.js';
import EllipsoidGeodesic from '../../../Core/EllipsoidGeodesic.js';
import EllipseGeometryLibrary from '../../../Core/EllipseGeometryLibrary.js';
import buildModuleUrl from '../../../Core/buildModuleUrl.js';
import algorithm from './algorithm.js';
import Math from '../../../Core/Math.js';
import SceneTransforms from '../../../Scene/SceneTransforms.js';
import PolylineGlowMaterialProperty from '../../../DataSources/PolylineGlowMaterialProperty.js';
import ClassificationType from '../../../Scene/ClassificationType.js';
    /**
     * @alias DTPolylineDrawer
     * @constructor
     * @description DTPolylineDrawer折线绘制类
     * @param {Viewer} [viewer] Viewer实例对象:
     */
    function DTPolylineDrawer(viewer) {
        this._viewer = viewer;
        this._scene = viewer.scene;
        this._clock = viewer.clock;
        this._canvas = viewer.scene.canvas;
        this._camera = viewer.scene.camera;
        this._ellipsoid = viewer.scene.globe.ellipsoid;
        this._tooltip = new DTTooltip(viewer.container);
        this._entity = null;
        this._tempPositions = [];
        this._positions = [];
        this._drawHandler = null;
        this._modifyHandler = null;
        this._okHandler = null;
        this._cancelHandler = null;
        this._dragIcon = buildModuleUrl("Assets/Images/circle_gray.png");
        this._dragIconLight = buildModuleUrl("Assets/Images/circle_red.png");
        this._material = null;
        this._markers = {};
        this._layerId = "globeEntityDrawerLayer";
        this._lineWidth=8;//新增
        this._classificationType=ClassificationType.BOTH;//新增
        this._rightClickEndDraw=false;//新增是否右键结束绘制
    }
    Object.defineProperties(DTPolylineDrawer.prototype, {
         /**
         * viewer实例对象
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        viewer: {
            get: function () {
                return this._viewer;
            }
        },
        /**
         * scene实例对象
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        scene: {
            get: function () {
                return this._scene;
            }
        },
        /**
         * clock实例对象
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        clock: {
            get: function () {
                return this._clock;
            }
        },
        /**
         * canvas实例对象
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        canvas: {
            get: function () {
                return this._canvas;
            }
        },
        /**
         * camera实例对象
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        camera: {
            get: function () {
                return this._camera;
            }
        },
        /**
         * ellipsoid实例对象
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        ellipsoid: {
            get: function () {
                return this._ellipsoid;
            }
        },
        /**
         * tooltip实例对象
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        tooltip: {
            get: function () {
                return this._tooltip;
            }
        },
        /**
         * 当前entity对象
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        entity: {
            get: function () {
                return this._entity;
            },
            set: function (value) {
                this._entity = value
            }
        },
         /**
         * 折线的临时坐标点
         * @memberof DTPolylineDrawer.prototype
         * @type {Array}
         */
        tempPositions: {
            get: function () {
                return this._tempPositions;
            },
            set: function (value) {
                this._tempPositions = value
            }
        },
        /**
         * 折线的坐标点
         * @memberof DTPolylineDrawer.prototype
         * @type {Array}
         */
        positions: {
            get: function () {
                return this._positions;
            },
            set: function (value) {
                this._positions = value
            }
        },
        /**
         * 绘制的Handler
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        drawHandler: {
            get: function () {
                return this._drawHandler;
            },
            set: function (value) {
                this._drawHandler = value
            }
        },
        /**
         * 修改的Handler
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        modifyHandler: {
            get: function () {
                return this._modifyHandler;
            },
            set: function (value) {
                this._modifyHandler = value
            }
        },
        /**
         * 生成折线的回调函数，也可以仅仅获取点
         * @memberof DTPolylineDrawer.prototype
         * @type {Function}
         */
        okHandler: {
            get: function () {
                return this._okHandler;
            },
            set: function (value) {
                this._okHandler = value
            }
        },
        /**
         * 取消生成折线的回调函数
         * @memberof DTPolylineDrawer.prototype
         * @type {Function}
         */
        cancelHandler: {
            get: function () {
                return this._cancelHandler;
            },
            set: function (value) {
                this._cancelHandler = value
            }
        },
         /**
         * 折线的材质
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        material: {
            get: function () {
                return this._material;
            },
            set: function (value) {
                this._material = value
            }
        },
         /**
         * 标识entity
         * @memberof DTPolylineDrawer.prototype
         * @type {String}
         */
        layerId: {
            get: function () {
                return this._layerId;
            }
        },
        /**
         * 提示点
         * @memberof DTPolylineDrawer.prototype
         * @type {Object}
         */
        markers: {
            get: function () {
                return this._markers;
            },
            set: function (value) {
                this._markers = value
            }
        },
        /**
         * 线宽
         * @memberof DTPolylineDrawer.prototype
         * @type {Int}
         */
        lineWidth: {//新增
            get: function () {
                return this._lineWidth;
            },
            set: function (value) {
                this._lineWidth = value
            }
        },
        /**
         * classificationType类型（分为贴地、贴模型、既贴地又贴模型）
         * @memberof DTPolylineDrawer.prototype
         * @type {Int}
         */
        classificationType: {//新增
            get: function () {
                return this._classificationType;
            },
            set: function (value) {
                this._classificationType = value;
            }
        },
        rightClickEndDraw:{
            get:function(){
               return this._rightClickEndDraw;
            },
            set:function(value){
              this._rightClickEndDraw=value;
            }
        }
    })
    /**
     * 绘制命令销毁，并不是类的销毁
     */
    DTPolylineDrawer.prototype.clear = function () {
        if (this.drawHandler) {
            this.drawHandler.destroy();
            this.drawHandler = null;
        }
        if (this.modifyHandler) {
            this.modifyHandler.destroy();
            this.modifyHandler = null;
        }
        clearMarkers(this, this.layerId);
        this.tooltip.setVisible(false);
    }
    /**
     * 绘制成功结束后的回调函数
     */
    DTPolylineDrawer.prototype.excuteOkHandler = function () {
        if (this.okHandler) {
            var positions = getPositionsWithSid(this);
            var lonLats = getLonLats(this, positions);
            this.clear();
            this.positions = positions;
            this.okHandler(positions, lonLats);
        } else {
            this.clear();
        }
    }
    /**
     * 取消绘制结果的回调函数
     */
    DTPolylineDrawer.prototype.excuteCancelHandler = function () {
        this.clear();
        if (this.cancelHandler) {
            this.cancelHandler();
        }
    }
     /**
     * 显示绘制的geometry,用户无需调用
     */
    DTPolylineDrawer.prototype.showModifyPolyline = function (positions, okHandler, cancelHandler) {
        this.positions = positions;
        this.okHandler = okHandler;
        this.cancelHandler = cancelHandler;
        //弹出diglog
        //this.tooltip.dialogShowAt(SceneTransforms.wgs84ToWindowCoordinates(this._scene, this.positions[0]), this);
        showModifyPolyline2Map(this);
    }
    /**
     * 绘制折线的命令，单独使用此类，可调用该方法进行绘制折线
     * @param {Function} okHandler 生成折线对象回调函数
     * @param {Function} cancelHandler 取消生成折线对象函数
     */
    DTPolylineDrawer.prototype.startDrawPolyline = function (okHandler, cancelHandler) {
        var _this = this;
        _this.okHandler = okHandler;
        _this.cancelHandler = cancelHandler;

        _this.positions = [];
        var floatingPoint = null;
        _this.drawHandler = new ScreenSpaceEventHandler(_this.canvas);
        _this.drawHandler.setInputAction(function (event) {
            var position = event.position;
            if (!defined(position)) {
                return;
            }
            // if (_this.positions.length < 2) {
            //     _this.tooltip.dialogShowAt(position, _this);
            // }
            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            var num = _this.positions.length;
            if (num == 0) {
                _this.positions.push(cartesian);
                floatingPoint = createPoint(_this, cartesian, -1);
                showPolyline2Map(_this);
            }
            _this.positions.push(cartesian);
            var oid = _this.positions.length - 2;
            createPoint(_this, cartesian, oid);
        }, ScreenSpaceEventType.LEFT_CLICK);
        _this.drawHandler.setInputAction(function (event) {
            var position = event.endPosition;
            if (!defined(position)) {
                return;
            }
            if (_this.positions.length < 1) {
                _this.tooltip.showAt(position, "<p>选择起点</p>");
                return;
            }
            var num = _this.positions.length;
            var tip = "<p>点击添加下一个点</p>";
            if (num > 2) {
                tip += "<p>右键结束绘制</p>";
            }
            _this.tooltip.showAt(position, tip);

            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            floatingPoint.position.setValue(cartesian);
            _this.positions.pop();
            _this.positions.push(cartesian);
        }, ScreenSpaceEventType.MOUSE_MOVE);
        _this.drawHandler.setInputAction(function (movement) {
            if (_this.positions.length < 3) {
                return;
            }
            _this.positions.pop();
            _this.viewer.entities.remove(floatingPoint);
            _this.tooltip.setVisible(false);

            //进入编辑状态
            _this.clear();
            showModifyPolyline2Map(_this);
                ////////////////////////////////新增功能右键结束
            _this.excuteOkHandler();
        }, ScreenSpaceEventType.RIGHT_CLICK);
    }
    //编辑折线调用，属于内部函数
    function startModify(that) {
        var _this = that;
        var isMoving = false;
        var pickedAnchor = null;
        if (_this.drawHandler) {
            _this.drawHandler.destroy();
            _this.drawHandler = null;
        }
        _this.modifyHandler = new ScreenSpaceEventHandler(_this.canvas);
        _this.modifyHandler.setInputAction(function (event) {
            var position = event.position;
            if (!defined(position)) {
                return;
            }
            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            if (isMoving) {
                isMoving = false;
                pickedAnchor.position.setValue(cartesian);
                var oid = pickedAnchor.oid;
                _this.tempPositions[oid] = cartesian;
                _this.tooltip.setVisible(false);
                if (pickedAnchor.flag == "mid_anchor") {
                    updateModifyAnchors(_this, oid);
                }
                if (!_this.rightClickEndDraw) {
                    _this.excuteOkHandler();
                }
            } else {
                var pickedObject = _this.scene.pick(position);
                if (!defined(pickedObject)) {
                    return;
                }
                if (!defined(pickedObject.id)) {
                    return;
                }
                var entity = pickedObject.id;
                if (entity.layerId != _this.layerId) {
                    return;
                }
                if (entity.flag != "anchor" && entity.flag != "mid_anchor") {
                    return;
                }
                pickedAnchor = entity;
                isMoving = true;
                if (entity.flag == "anchor") {
                    _this.tooltip.showAt(position, "<p>移动控制点</p>");
                }
                if (entity.flag == "mid_anchor") {
                    _this.tooltip.showAt(position, "<p>移动创建新的控制点</p>");
                }
            }
        }, ScreenSpaceEventType.LEFT_CLICK);
        _this.modifyHandler.setInputAction(function (event) {
            if (!isMoving) {
                return;
            }
            var position = event.endPosition;
            if (!defined(position)) {
                return;
            }
            _this.tooltip.showAt(position, "<p>移动控制点</p>");

            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            var cartesian = _this.scene.globe.pick(ray, _this.scene);
            if (!defined(cartesian)) {
                return;
            }
            var oid = pickedAnchor.oid;
            if (pickedAnchor.flag == "anchor") {
                pickedAnchor.position.setValue(cartesian);
                _this.tempPositions[oid] = cartesian;
                //左右两个中点
                updateNewMidAnchors(_this, oid);
            } else if (pickedAnchor.flag == "mid_anchor") {
                pickedAnchor.position.setValue(cartesian);
                _this.tempPositions[oid] = cartesian;
            }
        }, ScreenSpaceEventType.MOUSE_MOVE);
        ////////////////////////////////新增功能右键结束编辑
        _this.modifyHandler.setInputAction(function (movement) {
            if (_this.rightClickEndDraw) {
                _this.excuteOkHandler();
            }
        }, ScreenSpaceEventType.RIGHT_CLICK);
    }
    //实时将折线展示到地图上
    function showPolyline2Map(that) {
        var _this = that;
        ////
        _this.material=null;
        _this.classificationType=ClassificationType.BOTH;
        _this.lineWidth=8;
        ///
        if (_this.material == null) {
            _this.material = new PolylineGlowMaterialProperty({
                glowPower: 0.25,
                color: Color.fromCssColorString('#00f').withAlpha(0.9)
            });
        }
        var dynamicPositions = new CallbackProperty(function () {
            return _this.positions;
        }, false);
        var bData = {
            polyline: {
                positions: dynamicPositions,
                clampToGround: true,
                width: _this.lineWidth,//新增
                material: _this.material,
                classificationType:_this.classificationType//新增
            }
        };
        _this.entity = _this.viewer.entities.add(bData);
        _this.entity.layerId = _this.layerId;
    }
    //编辑折线调用，属于内部函数
    function showModifyPolyline2Map(that) {
        var _this = that;
        startModify(_this);
        computeTempPositions(_this);

        var dynamicPositions = new CallbackProperty(function () {
            return _this.tempPositions;
        }, false);
        if (_this.material == null) {
            _this.material = new PolylineGlowMaterialProperty({
                glowPower: 0.25,
                color: Color.fromCssColorString('#00f').withAlpha(0.9)
            });
        }
        var bData = {
            polyline: {
                positions: dynamicPositions,
                clampToGround: true,
                width: _this.lineWidth,//新增
                material: _this.material,
                classificationType:_this.classificationType//新增
            }
        };
        _this.entity = _this.viewer.entities.add(bData);
        _this.entity.layerId = _this.layerId;
        var positions = _this.tempPositions;
        for (var i = 0; i < positions.length; i++) {
            var ys = i % 2;
            if (ys == 0) {
                createPoint(_this, positions[i], i);
            } else {
                createMidPoint(_this, positions[i], i);
            }
        }
    }
    //更新提示点的位置
    function updateModifyAnchors(that, oid) {
        var _this = that;
        //重新计算tempPositions
        var num = _this.tempPositions.length;
        if (oid == 0 || oid == num - 1) {
            return;
        }
        //重新计算tempPositions
        var p = _this.tempPositions[oid];
        var p1 = _this.tempPositions[oid - 1];
        var p2 = _this.tempPositions[oid + 1];

        //计算中心
        var cp1 = computeCenterPotition(_this, p1, p);
        var cp2 = computeCenterPotition(_this, p, p2);

        //插入点
        var arr = [cp1, p, cp2];
        _this.tempPositions.splice(oid, 1, cp1, p, cp2);

        //重新加载锚点
        clearAnchors(_this);
        var positions = _this.tempPositions;
        for (var i = 0; i < positions.length; i++) {
            var ys = i % 2;
            if (ys == 0) {
                createPoint(_this, positions[i], i);
            } else {
                createMidPoint(_this, positions[i], i);
            }
        }
    }
    //更新中间灰色提示点的位置
    function updateNewMidAnchors(that, oid) {
        var _this = that;
        if (oid == null || oid == undefined) {
            return;
        }
        //左边两个中点，oid2为临时中间点
        var oid1 = null;
        var oid2 = null;
        //右边两个中点，oid3为临时中间点
        var oid3 = null;
        var oid4 = null;

        var num = _this.tempPositions.length;
        if (oid == 0) {
            oid1 = num - 2;
            oid2 = num - 1;
            oid3 = oid + 1;
            oid4 = oid + 2;
        } else if (oid == num - 2) {
            oid1 = oid - 2;
            oid2 = oid - 1;
            oid3 = num - 1;
            oid4 = 0;
        } else {
            oid1 = oid - 2;
            oid2 = oid - 1;
            oid3 = oid + 1;
            oid4 = oid + 2;
        }

        var c1 = _this.tempPositions[oid1];
        var c = _this.tempPositions[oid];
        var c4 = _this.tempPositions[oid4];

        if (oid == 0) {
            var c3 = computeCenterPotition(_this, c4, c);
            _this.tempPositions[oid3] = c3;
            _this.markers[oid3].position.setValue(c3);
        } else if (oid == num - 1) {
            var c2 = computeCenterPotition(_this, c1, c);
            _this.tempPositions[oid2] = c2;
            _this.markers[oid2].position.setValue(c2);
        } else {
            var c2 = computeCenterPotition(_this, c1, c);
            var c3 = computeCenterPotition(_this, c4, c);
            _this.tempPositions[oid2] = c2;
            _this.tempPositions[oid3] = c3;
            _this.markers[oid2].position.setValue(c2);
            _this.markers[oid3].position.setValue(c3);
        }
    }
    //创建端点提示点
    function createPoint(that, cartesian, oid) {
        var _this = that;
        var point = _this.viewer.entities.add({
            position: cartesian,
            billboard: {
                image: _this._dragIconLight,
                eyeOffset: new ConstantProperty(new Cartesian3(0, 0, 0)),
                heightReference: HeightReference.CLAMP_TO_GROUND
            }
        });
        point.oid = oid;
        point.sid = cartesian.sid; //记录原始序号
        point.layerId = _this.layerId;
        point.flag = "anchor";
        _this.markers[oid] = point;
        return point;
    }
    //创建中间提示点
    function createMidPoint(that, cartesian, oid) {
        var _this = that;
        var point = _this.viewer.entities.add({
            position: cartesian,
            billboard: {
                image: _this._dragIcon,
                eyeOffset: new ConstantProperty(new Cartesian3(0, 0, 0)),
                heightReference: HeightReference.CLAMP_TO_GROUND
            }
        });
        point.oid = oid;
        point.layerId = _this.layerId;
        point.flag = "mid_anchor";
        _this.markers[oid] = point;
        return point;
    }
    //计算暂时点
    function computeTempPositions(that) {
        var _this = that;
        var pnts = [].concat(_this.positions);
        var num = pnts.length;
        _this.tempPositions = [];
        for (var i = 1; i < num; i++) {
            var p1 = pnts[i - 1];
            var p2 = pnts[i];
            p1.sid = i - 1;
            p2.sid = i;
            var cp = computeCenterPotition(_this, p1, p2);
            _this.tempPositions.push(p1);
            _this.tempPositions.push(cp);
        }
        var last = pnts[num - 1];
        _this.tempPositions.push(last);
    }
    //计算中间点
    function computeCenterPotition(that, p1, p2) {
        var _this = that;
        var c1 = _this.ellipsoid.cartesianToCartographic(p1);
        var c2 = _this.ellipsoid.cartesianToCartographic(p2);
        var cm = new EllipsoidGeodesic(c1, c2).interpolateUsingFraction(0.5);
        var cp = _this.ellipsoid.cartographicToCartesian(cm);
        return cp;
    }
    //是否为xyz
    function isSimpleXYZ(p1, p2) {
        if (p1.x == p2.x && p1.y == p2.y && p1.z == p2.z) {
            return true;
        }
        return false;
    }
    //清空所有端点提示点
    function clearMarkers(that, layerName) {
        var _this = that;
        var viewer = _this.viewer;
        var entityList = viewer.entities.values;
        if (entityList == null || entityList.length < 1)
            return;
        for (var i = 0; i < entityList.length; i++) {
            var entity = entityList[i];
            if (entity.layerId == layerName) {
                viewer.entities.remove(entity);
                i--;
            }
        }
    }
    //清空所有中间灰色提示点
    function clearAnchors(that) {
        var _this = that;
        for (var key in _this.markers) {
            var m = _this.markers[key];
            _this.viewer.entities.remove(m);
        }
        _this.markers = {};
    }
    //获取cartesian中自定义的sid
    function getPositionsWithSid(that) {
        var _this = that;
        var viewer = _this.viewer;
        var rlt = [];
        var entityList = viewer.entities.values;
        if (entityList == null || entityList.length < 1) {
            return rlt;
        }
        for (var i = 0; i < entityList.length; i++) {
            var entity = entityList[i];
            if (entity.layerId != _this.layerId) {
                continue;
            }
            if (entity.flag != "anchor") {
                continue;
            }
            var p = entity.position.getValue(new Date().getTime());
            p.sid = entity.sid;
            p.oid = entity.oid;
            rlt.push(p);
        }
        //排序
        rlt.sort(function (obj1, obj2) {
            if (obj1.oid > obj2.oid) {
                return 1;
            }
            else if (obj1.oid == obj2.oid) {
                return 0;
            }
            else {
                return -1;
            }
        });
        return rlt;
    }
    //单个世界坐标转经纬度坐标
    function getLonLat(that, cartesian) {
        var _this = that;
        var cartographic = _this.ellipsoid.cartesianToCartographic(cartesian);
        cartographic.height = _this.viewer.scene.globe.getHeight(cartographic);
        var pos = {
            lon: cartographic.longitude,
            lat: cartographic.latitude,
            alt: cartographic.height,
            height: cartographic.height
        };
        pos.lon = Math.toDegrees(pos.lon);
        pos.lat = Math.toDegrees(pos.lat);
        return pos;
    }
    //批量世界坐标转经纬度坐标
    function getLonLats(that, positions) {
        var arr = [];
        for (var i = 0; i < positions.length; i++) {
            var c = positions[i];
            var p = getLonLat(that, c);
            p.sid = c.sid;
            p.oid = c.oid;
            arr.push(p);
        }
        return arr;
    }
export default DTPolylineDrawer;
