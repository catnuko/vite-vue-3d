import DTTooltip from './DTTooltip.js';
import ScreenSpaceEventHandler from '../../../Core/ScreenSpaceEventHandler.js';
import defined from '../../../Core/defined.js';
import ScreenSpaceEventType from '../../../Core/ScreenSpaceEventType.js';
import ConstantProperty from '../../../DataSources/ConstantProperty.js';
import HeightReference from '../../../Scene/HeightReference.js';
import Cartesian3 from '../../../Core/Cartesian3.js';
import Cartesian2 from '../../../Core/Cartesian2.js';
import Color from '../../../Core/Color.js';
import PolylineDashMaterialProperty from '../../../DataSources/PolylineDashMaterialProperty.js';
import CallbackProperty from '../../../DataSources/CallbackProperty.js';
import LabelStyle from '../../../Scene/LabelStyle.js';
import PolygonGraphics from '../../../DataSources/PolygonGraphics.js';
import EllipsoidGeodesic from '../../../Core/EllipsoidGeodesic.js';
import EllipseGeometryLibrary from '../../../Core/EllipseGeometryLibrary.js';
import buildModuleUrl from '../../../Core/buildModuleUrl.js';
import algorithm from './algorithm.js';
import Math from '../../../Core/Math.js';
import SceneTransforms from '../../../Scene/SceneTransforms.js';
import PolygonHierarchy from '../../../Core/PolygonHierarchy.js';
import ClassificationType from '../../../Scene/ClassificationType.js';
import Cesium3DTileFeature from '../../../Scene/Cesium3DTileFeature.js';
    /**
     * @alias DTPolygonDrawer
     * @constructor
     * @description DTPolygonDrawer多边形绘制类
     * @param {Viewer} [viewer] Viewer实例对象:
     */
    function DTPolygonDrawer(viewer) {
        this._viewer = viewer;
        this._scene = viewer.scene;
        this._clock = viewer.clock;
        this._canvas = viewer.scene.canvas;
        this._camera = viewer.scene.camera;
        this._ellipsoid = viewer.scene.globe.ellipsoid;
        this._tooltip = new DTTooltip(viewer.container);
        this._entity = null;
        this._tempPositions = [];
        this._positions = [];
        this._drawHandler = null;
        this._modifyHandler = null;
        this._okHandler = null;
        this._cancelHandler = null;
        this._dragIcon = buildModuleUrl("Assets/Images/circle_gray.png");
        this._dragIconLight = buildModuleUrl("Assets/Images/circle_red.png");
        this._material = null;
        this._outlineMaterial = null;
        this._fill = true;
        this._outline = true;
        this._outlineWidth = 3;
        this._extrudedHeight = 0;
        this._toolBarIndex = null;
        this._executeHandlerType = null;
        this._markers = {};
        this._layerId = "globeEntityDrawerLayer";
        this._classificationType=ClassificationType.BOTH ;//新增
        this._rightClickEndDraw=false;//新增是否右键结束绘制
        this._markPoints=[];
        this._drawStatus=false;//编辑状态还是绘制状态
        this._copyPositions=[];//备份点，由于cesium自身浅拷贝的为问题、
        this._getCartWay=true;//false表示globe.pick，true表示scene.pickPosition
    }
    Object.defineProperties(DTPolygonDrawer.prototype, {
        /**
         * viewer实例对象
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        viewer: {
            get: function () {
                return this._viewer;
            }
        },
        /**
         * scene实例对象
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        scene: {
            get: function () {
                return this._scene;
            }
        },
        /**
         * clock实例对象
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        clock: {
            get: function () {
                return this._clock;
            }
        },
        /**
         * canvas实例对象
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        canvas: {
            get: function () {
                return this._canvas;
            }
        },
        /**
         * camera实例对象
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        camera: {
            get: function () {
                return this._camera;
            }
        },
        /**
         * ellipsoid实例对象
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        ellipsoid: {
            get: function () {
                return this._ellipsoid;
            }
        },
        /**
         * tooltip实例对象
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        tooltip: {
            get: function () {
                return this._tooltip;
            }
        },
        /**
         * 当前所绘制多边形的entity
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        entity: {
            get: function () {
                return this._entity;
            },
            set: function (value) {
                this._entity = value
            }
        },
         /**
         * 多边形的临时坐标点
         * @memberof DTPolygonDrawer.prototype
         * @type {Array}
         */
        tempPositions: {
            get: function () {
                return this._tempPositions;
            },
            set: function (value) {
                this._tempPositions = value
            }
        },
        /**
         * 多边形的坐标点
         * @memberof DTPolygonDrawer.prototype
         * @type {Array}
         */
        positions: {
            get: function () {
                return this._positions;
            },
            set: function (value) {
                this._positions = value
            }
        },
        /**
         * 多边形的绘制的Handler
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        drawHandler: {
            get: function () {
                return this._drawHandler;
            },
            set: function (value) {
                this._drawHandler = value
            }
        },
        /**
         * 多边形的编辑的Handler
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        modifyHandler: {
            get: function () {
                return this._modifyHandler;
            },
            set: function (value) {
                this._modifyHandler = value
            }
        },
        /**
         * 生成多边形的回调函数，也可以仅仅获取点
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        okHandler: {
            get: function () {
                return this._okHandler;
            },
            set: function (value) {
                this._okHandler = value
            }
        },
         /**
         * 取消生成多边形的回调函数
         * @memberof DTPolygonDrawer.prototype
         * @type {Function}
         */
        cancelHandler: {
            get: function () {
                return this._cancelHandler;
            },
            set: function (value) {
                this._cancelHandler = value
            }
        },
        /**
         * 多边形的材质
         * @memberof DTPolygonDrawer.prototype
         * @type {Function}
         */
        material: {
            get: function () {
                return this._material;
            },
            set: function (value) {
                this._material = value
            }
        },
        /**
         * 多边形轮廓线的材质
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        outlineMaterial: {
            get: function () {
                return this._outlineMaterial;
            },
            set: function (value) {
                this._outlineMaterial = value
            }
        },
        /**
         * 多边形是否填充
         * @memberof DTPolygonDrawer.prototype
         * @type {Boolean}
         */
        fill: {
            get: function () {
                return this._fill;
            },
            set: function (value) {
                this._fill = value
            }
        },
        /**
         * 外轮廓线是否显示
         * @memberof DTPolygonDrawer.prototype
         * @type {Boolean}
         */
        outline: {
            get: function () {
                return this._outline;
            },
            set: function (value) {
                this._outline = value
            }
        },
        /**
         * 外轮廓线的宽度
         * @memberof DTPolygonDrawer.prototype
         * @type {Int}
         */
        outlineWidth: {
            get: function () {
                return this._outlineWidth;
            },
            set: function (value) {
                this._outlineWidth = value
            }
        },
        /**
         * 多边形拉伸高度
         * @memberof DTPolygonDrawer.prototype
         * @type {Int}
         */
        extrudedHeight: {
            get: function () {
                return this._extrudedHeight;
            },
            set: function (value) {
                this._extrudedHeight = value
            }
        },
        /**
         * 表示entity
         * @memberof DTPolygonDrawer.prototype
         * @type {String}
         */
        layerId: {
            get: function () {
                return this._layerId;
            }
        },
        /**
         * 执行的Handler类型
         * @memberof DTPolygonDrawer.prototype
         * @type {String}
         */
        executeHandlerType: {
            get: function () {
                return this._executeHandlerType;
            },
            set: function (value) {
                this._executeHandlerType = value
            }
        },
        /**
         * 提示点
         * @memberof DTPolygonDrawer.prototype
         * @type {Object}
         */
        markers: {
            get: function () {
                return this._markers;
            },
            set: function (value) {
                this._markers = value
            }
        },
        /**
         * classificationType类型（分为贴地、贴模型、既贴地又贴模型）
         * @memberof DTPolygonDrawer.prototype
         * @type {Int}
         */
        classificationType: {
            get: function () {
                return this._classificationType;
            },
            set: function (value) {
                this._classificationType = value
            }
        },
        rightClickEndDraw:{
            get:function(){
               return this._rightClickEndDraw;
            },
            set:function(value){
              this._rightClickEndDraw=value;
            }
        }
    })
    /**
     * 绘制命令销毁，并不是类的销毁
     */
    DTPolygonDrawer.prototype.clear = function () {
        if (this.drawHandler) {
            this.drawHandler.destroy();
            this.drawHandler = null;
        }
        if (this.modifyHandler) {
            this.modifyHandler.destroy();
            this.modifyHandler = null;
        }
        clearMarkers(this, this.layerId);
        this.tooltip.setVisible(false);
    }
    /**
     * 绘制成功结束后的回调函数
     */
    DTPolygonDrawer.prototype.excuteOkHandler = function () {
        this.clear();
        if (this.okHandler) {
            var positions = [];
            for (var i = 0; i < this._copyPositions.length; i += 2) {
                var p = this._copyPositions[i];
                positions.push(p);
            }
            this.positions = positions;
            this.okHandler(positions);
        }
    }
    /**
     * 取消绘制结果的回调函数
     */
    DTPolygonDrawer.prototype.excuteCancelHandler = function () {
        this.clear();
        if (this.cancelHandler) {
            this.cancelHandler();
        }
    }
     /**
     * 显示绘制的geometry,用户无需调用
     */
    DTPolygonDrawer.prototype.showModifyPolygon = function (positions, okHandler, cancelHandler) {
        var _this = this;
        _this.positions = positions;
        _this.okHandler = okHandler;
        //弹出diglog
        //this.tooltip.dialogShowAt(SceneTransforms.wgs84ToWindowCoordinates(this._scene, _this.positions[0]), _this);
        _this.cancelHandler = cancelHandler;
        showModifyRegion2Map(_this);
    }
    /**
     * 绘制多边形的命令，单独使用此类，可调用该方法进行绘制多边形
     * @param {Function} okHandler 生成多边形对象回调函数
     * @param {Function} cancelHandler 取消生成多边形对象函数
     */
    DTPolygonDrawer.prototype.startDrawPolygon = function (okHandler, cancelHandler) {
        var _this = this;
        _this.okHandler = okHandler;
        _this.cancelHandler = cancelHandler;

        _this.positions = [];
        _this._markPoints=[];
        var floatingPoint = null;
        _this.drawHandler = new ScreenSpaceEventHandler(_this.canvas);

        _this.drawHandler.setInputAction(function (event) {
            var position = event.position;
            if (!defined(position)) {
                return;
            }

            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            //var cartesian = _this.scene.globe.pick(ray, _this.scene);
            var cartesian = GetCartesian(position, _this);
            if (!defined(cartesian)) {
                return;
            }
            var num = _this.positions.length;
            if (num == 0) {
                _this.positions.push(cartesian.clone());
                _this._markPoints.push(cartesian.clone());
                floatingPoint = createPoint(_this, cartesian, -1);
                showRegion2Map(_this);
            }
            _this.positions.push(cartesian.clone());
            _this._markPoints.push(cartesian.clone());
            var oid = _this.positions.length - 2;
            createPoint(_this, cartesian, oid);
        }, ScreenSpaceEventType.LEFT_CLICK);

        _this.drawHandler.setInputAction(function (event) {
            var position = event.endPosition;
            if (!defined(position)) {
                return;
            }
            if (_this.positions.length < 1) {
                _this.tooltip.showAt(position, "<p>选择起点</p>");
                return;
            }
            var num = _this.positions.length;
            var tip = "<p>点击添加下一个点</p>";
            if (num > 3) {
                tip += "<p>右键结束绘制</p>";
            }
            _this.tooltip.showAt(position, tip);
            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            //var cartesian = _this.scene.globe.pick(ray, _this.scene);
            var cartesian = GetCartesian(event.endPosition, _this);
            if (!defined(cartesian)) {
                return;
            }
            floatingPoint.position.setValue(cartesian);
            _this.positions.pop();
            _this._markPoints.pop();
            _this.positions.push(cartesian.clone());
            _this._markPoints.push(cartesian.clone());
        }, ScreenSpaceEventType.MOUSE_MOVE);

        _this.drawHandler.setInputAction(function (movement) {
            if (_this.positions.length < 4) {
                return;
            }
            _this.positions.pop();
            _this._markPoints.pop();
            _this.viewer.entities.remove(floatingPoint);
            _this.tooltip.setVisible(false);
            //进入编辑状态
            _this.clear();
            //设置绘制状态
            _this._drawStatus=true;
            showModifyRegion2Map(_this);
             _this.excuteOkHandler();
        }, ScreenSpaceEventType.RIGHT_CLICK);
    }
    //编辑多边形调用，属于内部函数
    function startModify(that) {
        var _this = that;
        var isMoving = false;
        var pickedAnchor = null;
        if (_this.drawHandler) {
            _this.drawHandler.destroy();
            _this.drawHandler = null;
        }
        _this.modifyHandler = new ScreenSpaceEventHandler(_this.canvas);

        _this.modifyHandler.setInputAction(function (event) {
            var position = event.position;
            if (!defined(position)) {
                return;
            }
            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            //var cartesian = _this.scene.globe.pick(ray, _this.scene);
            var cartesian = GetCartesian(position, _this);
            if (!defined(cartesian)) {
                return;
            }
            if (isMoving) {
                isMoving = false;
                pickedAnchor.position.setValue(cartesian);
                var oid = pickedAnchor.oid;
                _this.tempPositions[oid] = cartesian;
                _this._copyPositions[oid]=cartesian.clone();
                _this.tooltip.setVisible(false);
                if (pickedAnchor.flag == "mid_anchor") {
                    updateModifyAnchors(_this,_this.tempPositions ,oid);
                    updateModifyAnchors(_this,_this._copyPositions ,oid);
                }
                if (!_this.rightClickEndDraw) {
                    _this.excuteOkHandler();
                }
            } else {
                var pickedObject = _this.scene.pick(position);
                if (!defined(pickedObject)) {
                    return;
                }
                if (!defined(pickedObject.id)) {
                    return;
                }
                var entity = pickedObject.id;
                if (entity.layerId != _this.layerId) {
                    return;
                }
                if (entity.flag != "anchor" && entity.flag != "mid_anchor") {
                    return;
                }
                pickedAnchor = entity;
                isMoving = true;
                if (entity.flag == "anchor") {
                    _this.tooltip.showAt(position, "<p>移动控制点</p>");
                }
                if (entity.flag == "mid_anchor") {
                    _this.tooltip.showAt(position, "<p>移动创建新的控制点</p>");
                }
            }
        }, ScreenSpaceEventType.LEFT_CLICK);

        _this.modifyHandler.setInputAction(function (event) {
            if (!isMoving) {
                return;
            }
            var position = event.endPosition;
            if (!defined(position)) {
                return;
            }
            _this.tooltip.showAt(position, "<p>移动控制点</p>");
            var ray = _this.camera.getPickRay(position);
            if (!defined(ray)) {
                return;
            }
            //var cartesian = _this.scene.globe.pick(ray, _this.scene);
            var cartesian = GetCartesian(position, _this);
            if (!defined(cartesian)) {
                return;
            }
            var oid = pickedAnchor.oid;
            if (pickedAnchor.flag == "anchor") {
                pickedAnchor.position.setValue(cartesian);
                _this.tempPositions[oid] = cartesian;
                _this._copyPositions[oid]=cartesian.clone();
                //左右两个中点
                updateNewMidAnchors(_this,_this.tempPositions, oid);
                //更新copy
                updateNewMidAnchors(_this,_this._copyPositions, oid);
            } else if (pickedAnchor.flag == "mid_anchor") {
                pickedAnchor.position.setValue(cartesian);
                _this.tempPositions[oid] = cartesian;
                _this._copyPositions[oid]=cartesian.clone();
            }
        }, ScreenSpaceEventType.MOUSE_MOVE);
        ////////////////////////////////新增功能编辑右键结束
        _this.modifyHandler.setInputAction(function (movement) {
            if (_this.rightClickEndDraw) {
                _this.excuteOkHandler();
            }
        }, ScreenSpaceEventType.RIGHT_CLICK);
    }
    //将绘制过程中geometry显示到地图上
    function showRegion2Map(that) {
        var _this = that;
        ////
        _this.material=null;
        _this.outlineMaterial=null;
        _this.classificationType=ClassificationType.BOTH;
        _this.outlineWidth=2;
        ///
        if (_this.material == null) {
            _this.material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        }
        if (_this.outlineMaterial == null) {
            _this.outlineMaterial = new PolylineDashMaterialProperty({
                dashLength: 16,
                color: Color.fromCssColorString('#00f').withAlpha(0.7)
            });
        }
        var dynamicPositions = new CallbackProperty(function () {
            return  new PolygonHierarchy (_this.positions);
        }, false);
        var outlineDynamicPositions = new CallbackProperty(function () {
            if (_this.positions.length > 1) {
                var arr = [].concat(_this.positions);
                var first = _this.positions[0];
                arr.push(first);
                return arr;
            } else {
                return null;
            }
        }, false);
        var bData = {
            polygon: new PolygonGraphics({
                hierarchy: dynamicPositions,
                material: _this.material,
                show: _this.fill,
                classificationType:_this.classificationType,
                // perPositionHeight:true
            }),
            polyline: {
                positions: outlineDynamicPositions,
                clampToGround: true,
                width: _this.outlineWidth,
                material: _this.outlineMaterial,
                show: _this.outline,
                classificationType:_this.classificationType
            }
        };
        if (_this.extrudedHeight > 0) {
            bData.polygon.extrudedHeight = _this.extrudedHeight;
            bData.polygon.extrudedHeightReference = HeightReference.RELATIVE_TO_GROUND;
            bData.polygon.closeTop = true;
            bData.polygon.closeBottom = true;
        }
        _this.entity = _this.viewer.entities.add(bData);
        _this.entity.layerId = _this.layerId;
    }
    //编辑多边形，实时将多边形geomtry显示到地图上
    function showModifyRegion2Map(that) {
        var _this = that;
        startModify(_this);
        computeTempPositions(_this);
        var dynamicPositions = new CallbackProperty(function () {
            return new PolygonHierarchy (_this.tempPositions);
        }, false);
        var outlineDynamicPositions = new CallbackProperty(function () {
            if (_this.tempPositions.length > 1) {
                var arr = [].concat(_this.tempPositions);
                var first = _this.tempPositions[0];
                arr.push(first);
                return arr;
            } else {
                return null;
            }
        }, false);
        if (_this.material == null) {
            _this.material = Color.fromCssColorString('#ff0').withAlpha(0.5);
        }
        if (_this.outlineMaterial == null) {
            _this.outlineMaterial = new PolylineDashMaterialProperty({
                dashLength: 16,
                color: Color.fromCssColorString('#00f').withAlpha(0.7)
            });
        }
        var bData = {
            polygon: new PolygonGraphics({
                hierarchy:dynamicPositions,
                material: _this.material,
                show: _this.fill,
                classificationType:_this.classificationType,
                //perPositionHeight:true
            }),
            polyline: {
                positions: outlineDynamicPositions,
                clampToGround: true,
                width: _this.outlineWidth,
                material: _this.outlineMaterial,
                show: _this.outline,
                classificationType:_this.classificationType
            }
        };
        if (_this.extrudedHeight > 0) {
            bData.polygon.extrudedHeight = _this.extrudedHeight;
            bData.polygon.extrudedHeightReference = HeightReference.RELATIVE_TO_GROUND;
            bData.polygon.closeTop = true;
            bData.polygon.closeBottom = true;
        }
        _this.entity = _this.viewer.entities.add(bData);
        _this.entity.layerId = _this.layerId;
        var positions = _this.tempPositions;
        for (var i = 0; i < positions.length; i++) {
            var ys = i % 2;
            if (ys == 0) {
                createPoint(_this, positions[i], i);
            } else {
                createMidPoint(_this, positions[i], i);
            }
        }
    }
    //更新提示点的位置
    function updateModifyAnchors(that,tempPositions, oid) {
        var _this = that;
        //重新计算tempPositions
        var p = tempPositions[oid];
        var p1 = null;
        var p2 = null;
        var num = tempPositions.length;
        if (oid == 0) {
            p1 = tempPositions[num - 1];
            p2 = tempPositions[oid + 1];
        } else if (oid == num - 1) {
            p1 = tempPositions[oid - 1];
            p2 = tempPositions[0];
        } else {
            p1 = tempPositions[oid - 1];
            p2 = tempPositions[oid + 1];
        }
        //计算中心
        var cp1 = computeCenterPotition(_this, p1, p);
        var cp2 = computeCenterPotition(_this, p, p2);
        //插入点
        var arr = [cp1, p, cp2];
        tempPositions.splice(oid, 1, cp1, p, cp2);
        //重新加载锚点
        clearAnchors(_this);
        var positions = tempPositions;
        for (var i = 0; i < positions.length; i++) {
            var ys = i % 2;
            if (ys == 0) {
                createPoint(_this, positions[i], i);
            } else {
                createMidPoint(_this, positions[i], i);
            }
        }
    }
    //更新中间灰色提示点的位置
    function updateNewMidAnchors(that, tempPositions,oid) {
        var _this = that;
        if (oid == null || oid == undefined) {
            return;
        }
        //左边两个中点，oid2为临时中间点
        var oid1 = null;
        var oid2 = null;
        //右边两个中点，oid3为临时中间点
        var oid3 = null;
        var oid4 = null;
        var num = tempPositions.length;
        if (oid == 0) {
            oid1 = num - 2;
            oid2 = num - 1;
            oid3 = oid + 1;
            oid4 = oid + 2;
        } else if (oid == num - 2) {
            oid1 = oid - 2;
            oid2 = oid - 1;
            oid3 = num - 1;
            oid4 = 0;
        } else {
            oid1 = oid - 2;
            oid2 = oid - 1;
            oid3 = oid + 1;
            oid4 = oid + 2;
        }
        var c1 = tempPositions[oid1];
        var c = tempPositions[oid];
        var c4 = tempPositions[oid4];

        var c2 = computeCenterPotition(_this, c1, c);
        var c3 = computeCenterPotition(_this, c4, c);

        tempPositions[oid2] = c2;
        tempPositions[oid3] = c3;

        _this.markers[oid2].position.setValue(c2);
        _this.markers[oid3].position.setValue(c3);
    }
    //创建端点提示点
    function createPoint(that, cartesian, oid) {
        let point = that.viewer.entities.add({
            position: cartesian,
            point: {
                pixelSize: 8,
                color: Color.RED,
                outlineColor: Color.WHITE,
                outlineWidth: 2,
                heightReference: HeightReference.NONE
                //distanceDisplayCondition:new Cesium.DistanceDisplayCondition(0,100000)
                //disableDepthTestDistance: Number.POSITIVE_INFINITY
              },
            // billboard: {
            //     image: that._dragIconLight,
            //     eyeOffset: new ConstantProperty(new Cartesian3(0, 0, 0)),
            //     heightReference: HeightReference.NONE
            // }
        });
        point.oid = oid;
        point.layerId = that.layerId;
        point.flag = "anchor";
        that.markers[oid] = point;
        return point;
    }
    //创建中间提示点
    function createMidPoint(that, cartesian, oid) {
        var _this = that;
        var point = that.viewer.entities.add({
            position: cartesian,
            point: {
                pixelSize: 8,
                color: Color.DARKGRAY ,
                outlineColor: Color.WHITE,
                outlineWidth: 2,

                //disableDepthTestDistance: Number.POSITIVE_INFINITY
              },
            // billboard: {
            //     image: that._dragIcon,
            //     eyeOffset: new ConstantProperty(new Cartesian3(0, 0, 0)),
            //     heightReference: HeightReference.CLAMP_TO_GROUND
            // }
        });
        point.oid = oid;
        point.layerId = _this.layerId;
        point.flag = "mid_anchor";
        that.markers[oid] = point;
        return point;
    }
    //计算临时点
    function computeTempPositions(that) {
        var _this = that;
        var pnts;
        //判断是绘制，还是编辑
        if (_this._drawStatus) {
            pnts = [].concat(_this._markPoints);
            _this._drawStatus=false;
        } else {
            pnts = [].concat(_this.positions);
        }
        var num = pnts.length;
        var first = pnts[0];
        var last = pnts[num - 1];
        if (isSimpleXYZ(first, last) == false) {
            pnts.push(first);
            num += 1;
        }
        _this.tempPositions = [];
        //备份点
        _this._copyPositions=[];
        for (var i = 1; i < num; i++) {
            var p1 = pnts[i - 1];
            var p2 = pnts[i];
            var cp = computeCenterPotition(_this, p1, p2);
            _this.tempPositions.push(p1);
            _this.tempPositions.push(cp);

            _this._copyPositions.push(p1.clone());
            _this._copyPositions.push(cp.clone());
        }
    }
    //计算中间点
    function computeCenterPotition(that, p1, p2) {
        var _this = that;
        var c1 = _this.ellipsoid.cartesianToCartographic(p1);
        var c2 = _this.ellipsoid.cartesianToCartographic(p2);
        var cm = new EllipsoidGeodesic(c1, c2).interpolateUsingFraction(0.5);
        var cp = _this.ellipsoid.cartographicToCartesian(cm);
        return cp;
    }
    //是否为xyz
    function isSimpleXYZ(p1, p2) {
        if (p1.x == p2.x && p1.y == p2.y && p1.z == p2.z) {
            return true;
        }
        return false;
    }
    //清空所有端点提示点
    function clearMarkers(that, layerName) {
        var _this = that;
        var viewer = _this.viewer;
        var entityList = viewer.entities.values;
        if (entityList == null || entityList.length < 1)
            return;
        for (var i = 0; i < entityList.length; i++) {
            var entity = entityList[i];
            if (entity.layerId == layerName) {
                viewer.entities.remove(entity);
                i--;
            }
        }
    }
    //清空所有中间灰色提示点
    function clearAnchors(that) {
        var _this = that;
        for (var key in _this.markers) {
            var m = _this.markers[key];
            _this.viewer.entities.remove(m);
        }
        _this.markers = {};
    }
    //球皮和模型
    function GetCartesian(position, dtCircleDrawer) {
        let ray = dtCircleDrawer._viewer.camera.getPickRay(position.clone());
        let tempcartesian = dtCircleDrawer._viewer.scene.globe.pick(ray, dtCircleDrawer._viewer.scene);
        let tempcartesianPick = dtCircleDrawer._viewer.scene.pickPosition(position.clone());
        if (dtCircleDrawer._getCartWay) {
            return tempcartesianPick;
        }else{
            return tempcartesian;
        }

    }
export default DTPolygonDrawer;

